import React, { useEffect, useState } from 'react';
import styles from './Home.module.css';
import { useDispatch } from 'react-redux';
import { fetchAdmin, sendContactEmail } from '../store/action/userAppStorage';
import Loader from '../components/Modal/LoadingModal';
import Modal from '../components/Modal/Modal';


const ContactPage = () => {
    let [isLoading, setIsLoading] = useState(true)
    let dispatch = useDispatch()
    let [isShow, setIsShow] = useState(false)
    let [isAdminData, setIsAdminData] = useState({})
    let [isData, setIsData] = useState({})
    let [isMessageLoader, setIsMessageLoading] = useState(false)
    let [isError, setIsError] = useState(false)
    let [isErrorInfo, setIsErrorInfo] = useState(false)

    let handleChangeHandler = (e, nameField) => {
        let val = e.target.value
        setIsData(prev => {
            prev[`${nameField}`] = val
            let newData = { ...prev }
            return newData
        })
    }


     let load = async () => {
        //fetch admin details
        let res = await dispatch(fetchAdmin())
        if (!res.bool) {
            return setIsLoading(false)
        }
        setIsAdminData(res.message)
        return setIsLoading(false)
    }

    let loader = async () => {
        return setIsLoading(false)
    }

    useEffect(() => {
        load()
        setTimeout(() => {
            loader()
        }, 3000);
        
        
    }, [])




    let togglemenu = () => {
        setIsShow(prev => !prev)
    }


    let submitHandler = async(e) => {
        e.preventDefault()
        setIsMessageLoading(true)
        let res = await dispatch(sendContactEmail(isData))
        setIsMessageLoading(false)
        setIsError(true)
        setIsErrorInfo(res.message)
        return
    }

    let closeModal = ()=>{
        setIsError(false)
        setIsErrorInfo('')
    }




    return (<>
        {isMessageLoader && <Loader />}
        {isError && <Modal content={isErrorInfo} closeModal={closeModal} />}

        {isLoading ? <div className="preloader">
            <div className="loader">
                <div className="shadow"></div>
                <div className="box"></div>
            </div>
        </div> : ""}


        <div className='navbar-area'>
            <div className="luvion-responsive-nav">
                <div className="container">
                    <div className="luvion-responsive-menu">
                        <div className="logo">
                            <a href="/">
                                <img src="front/img/favicon.png" alt="logo" />
                                <img src="front/img/favicon.png" alt="logo" />
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <div className="luvion-nav">
                <div className="container">
                    <nav className="navbar navbar-expand-md navbar-light">
                        <a className="navbar-brand" href="/">
                            <img src="front/img/favicon.png" alt="logo" />
                            <img src="front/img/favicon.png" alt="logo" />
                        </a>

                        <div className="collapse navbar-collapse mean-menu" id="navbarSupportedContent">
                            <ul className="navbar-nav">
                                <li className="nav-item"><a href="/" className="nav-link active">HOME</a></li>

                                <li className="nav-item"><a href="#" className="nav-link">PERSONAL </a>
                                    <ul className="dropdown-menu">
                                        <li className="nav-item"><a href="/savings" className="nav-link">SAVINGS ACCOUNT</a></li>

                                        <li className="nav-item"><a href="/current" className="nav-link">CURRENT ACCOUNT</a></li>
                                    </ul>
                                </li>

                                <li className="nav-item"><a href="/about" className="nav-link">ABOUT US</a></li>



                                <li className="nav-item"><a href="/cards" className="nav-link">CARDS</a></li>


                                <li className="nav-item"><a href="/faq" className="nav-link">FAQ</a></li>

                                <li className="nav-item"><a href="/contact" className="nav-link">CONTACT</a></li>
                            </ul>

                            <div className="others-options">
                                <a href="/login" target="_blank" className="login-btn">
                                    <strong><i className="flaticon-user"></i> ONLINE BANKING</strong></a>
                            </div>
                        </div>





                    </nav>
                </div>
            </div>

            <button type="button" className="visitor-menu-toggle" onClick={togglemenu} aria-label={isShow ? "Close navigation" : "Open navigation"} aria-expanded={isShow}>
                <i className="fas fa-bars" aria-hidden="true"></i>
            </button>


            <div className={`visitor-mobile-menu ${isShow ? "is-open" : ""}`}>
                <ul className={styles.listcontainer}>
                    <li className={styles.listitem}><a href="/" >HOME</a></li>

                    <li className={styles.listitemexpand}><a href="/savings" >SAVINGS ACCOUNT</a>

                    </li>
                    <li className={styles.listitemexpand}><a href="/current" >CURRENT ACCOUNT </a>

                    </li>

                    <li className={styles.listitem}><a href="/about" >ABOUT US</a></li>



                    <li className={styles.listitem}><a href="/cards" >CARDS</a></li>




                    <li className={styles.listitem}><a href="/contact" >CONTACT</a></li>
                    <li className={styles.listitemlast}><a href="/login" >LOGIN</a><a href="/signup" >SIGNUP</a></li>
                </ul>


            </div>
        </div>



        <div className="page-title-area item-bg1 jarallax" data-jarallax='{"speed": 0.3}'>
            <div className="container">
                <div className="page-title-content">
                    <h2>CONTACT US</h2>
                </div>
            </div>
        </div>


        <section class="contact-area ptb-70">
            <div class="container">
                <div class="section-title">
                    <h2>Drop us message for any query</h2>
                    <div class="bar"></div>
                </div>

                <div class="row">
                    <div class="col-lg-5 col-md-12">
                        <div class="contact-info">
                            <ul>
                                <li>
                                    <div class="icon">
                                        <i class="fas fa-map-marker-alt"></i>
                                    </div>
                                    <span>Address</span> {isAdminData.location}
                                </li>

                                <li>
                                    <div class="icon">
                                        <i class="fas fa-envelope"></i>
                                    </div>
                                    <span>Email</span>
                                    <a href="https://templates.envytheme.com/cdn-cgi/l/email-protection#5139343d3d3e113d2427383e3f7f323e3c"><span class="__cf_email__" data-cfemail="acc4c9c0c0c3ecc0d9dac5c3c282cfc3c1">[email&#160;protected]</span></a>
                                    <a href="https://templates.envytheme.com/cdn-cgi/l/email-protection#472b32312e282907202a262e2b6924282a"><span class="__cf_email__" data-cfemail="6d01181b0402032d0a000c0401430e0200">[email&#160;protected]</span></a>
                                </li>

                                <li>
                                    <div class="icon">
                                        <i class="fas fa-phone-volume"></i>
                                    </div>
                                    <span>Phone</span>
                                    <a href="tel:+44587154756">{isAdminData.phone}</a>
                                    <a href="tel:+55555514574">{isAdminData.phone}</a>
                                </li>
                            </ul>
                        </div>
                    </div>

                    <div class="col-lg-7 col-md-12">
                        <div class="contact-form">
                            <form id="contactForm" onSubmit={submitHandler}>
                                <div class="row">
                                    <div class="col-lg-6 col-md-6">

                                        <div class="form-group">
                                            <input type="text" name="name" id="name" class="form-control" required data-error="Please enter your name" placeholder="Name" onChange={(e) => handleChangeHandler(e, 'name')} />
                                            <div class="help-block with-errors"></div>
                                        </div>


                                    </div>

                                    <div class="col-lg-6 col-md-6">

                                        <div class="form-group">
                                            <input type="email" name="email" id="email" class="form-control" required data-error="Please enter your email" placeholder="Email" onChange={(e) => handleChangeHandler(e, 'email')} />
                                            <div class="help-block with-errors"></div>
                                        </div>

                                    </div>

                                    <div class="col-lg-6 col-md-6">

                                        <div class="form-group">
                                            <input type="text" name="phone_number" id="phone_number" required data-error="Please enter your number" class="form-control" placeholder="Phone" onChange={(e) => handleChangeHandler(e, 'phone')} />
                                            <div class="help-block with-errors"></div>
                                        </div>
                                    </div>

                                    <div class="col-lg-6 col-md-6">
                                        <div class="form-group">
                                            <input type="text" name="msg_subject" id="msg_subject" class="form-control" required data-error="Please enter your subject" placeholder="Subject" onChange={(e) => handleChangeHandler(e, 'msg_subject')} />
                                            <div class="help-block with-errors"></div>
                                        </div>
                                    </div>

                                    <div class="col-lg-12 col-md-12">
                                        <div class="form-group">
                                            <textarea name="message" class="form-control" id="message" cols="30" rows="6" required data-error="Write your message" placeholder="Your Message" onChange={(e) => handleChangeHandler(e, 'message')} ></textarea>
                                            <div class="help-block with-errors"></div>
                                        </div>
                                    </div>

                                    <div class="col-lg-12 col-md-12">
                                        <button type="submit" class="btn btn-primary">Send Message</button>
                                        <div id="msgSubmit" class="h3 text-center hidden"></div>
                                        <div class="clearfix"></div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <div class="bg-map"><img src="front/img/bg-map.png" alt="image" /></div>
        </section>



        <footer className="footer-area">
            <div className="container">
                <div className="row">
                    <div className="col-lg-3 col-sm-6 col-md-6">
                        <div className="single-footer-widget">
                            <div className="logo">
                                <a href="/" className="black-logo"><img src="front/img/favicon.png" alt="logo" /></a>

                                <p>Zentrixx Bank is focused on practical digital banking, responsive customer support and a better everyday experience.</p>
                            </div>

                            <ul className="social-links">
                                <li><a href="#" target="_blank"><i className="fab fa-facebook-f"></i></a></li>
                                <li><a href="#" target="_blank"><i className="fab fa-twitter"></i></a></li>
                                <li><a href="#" target="_blank"><i className="fab fa-instagram"></i></a></li>
                                <li><a href="#" target="_blank"><i className="fab fa-linkedin-in"></i></a></li>
                            </ul>
                        </div>
                    </div>

                    <div className="col-lg-3 col-sm-6 col-md-6">
                        <div className="single-footer-widget">
                            <h3>Company</h3>

                            <ul className="list">
                                <li><a href="/about">About Us</a></li>
                                <li>
                                    <a href="/savings">Savings</a>
                                </li>
                                <li><a href="/current">Checking</a></li>
                            </ul>
                        </div>
                    </div>

                    <div className="col-lg-3 col-sm-6 col-md-6">
                        <div className="single-footer-widget">
                            <h3>Support</h3>

                            <ul className="list">
                                <li><a href="/faq">FAQ's</a></li>
                                <li><a href="/privacy">Privacy Policy</a></li>
                                <li><a href="/contact">Contact Us</a></li>
                            </ul>
                        </div>
                    </div>

                    <div className="col-lg-3 col-sm-6 col-md-6">
                        <div className="single-footer-widget">
                            <h3>Address</h3>

                            <ul className="footer-contact-info">
                                <li><span>Location:</span>{isAdminData.location}</li>
                                <li><span>Phone:</span> <a href="">{isAdminData.phone}</a></li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div className="copyright-area">
                    <p>Copyright
                        <script>
                            document.write(new Date().getFullYear())
                        </script> | <a href="/" target="_blank">Smarter Banking</a></p>
                </div>
            </div>


        </footer>

        <div class="go-top"><i class="fas fa-arrow-up"></i></div>






    </>)


}

export default ContactPage
