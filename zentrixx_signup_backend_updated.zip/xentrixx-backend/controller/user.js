const { Resend } = require('resend');
const resend = new Resend(process.env.RESEND_API_KEY || process.env.RESEND);
const mongoose = require("mongoose");
const jwt = require("jsonwebtoken")
const { generateAcessToken, OneTimePasswordTemplate, WelcomeTemplate, NotifyAdmin, LoanRequestTemplate, CardRequestTemplate, SenderRequestTemplate, RecieverRequestTemplate, AdminCardRequestTemplate, AdminDepositRequestTemplate, AdminDebitRequestTemplate, AdminTransferRequestTemplate, AdminLoanRequestTemplate, contactEmail } = require('../utils/utils')
const { User, Token, RecoverToken, PhoneToken, Card, History, Beneficiaries, Notification, Account, Admin, Loan } = require("../database/databaseConfig");
const random_number = require("random-number")
const NanoId = require('nano-id');
const moment = require('moment')
const crypto = require("crypto")
let request = require('request');

const { verifyTransactionToken, verifyEmailTemplate, passwordResetTemplate, TransferRequestTemplate, DebitRequestTemplate, DepositRequestTemplate } = require('../utils/utils')


User.find().then(data=>{
   console.log(data)
})




const awsEncode = (value) => encodeURIComponent(value).replace(/[!'()*]/g, (char) =>
   `%${char.charCodeAt(0).toString(16).toUpperCase()}`
);
const sha256 = (value) => crypto.createHash("sha256").update(value, "utf8").digest("hex");
const hmac = (key, value, encoding) => crypto.createHmac("sha256", key).update(value, "utf8").digest(encoding);

const createS3PresignedPutUrl = ({ bucket, region, key, accessKeyId, secretAccessKey }) => {
   const host = `${bucket}.s3.${region}.amazonaws.com`;
   const amzDate = new Date().toISOString().replace(/[:-]|\.\d{3}/g, "");
   const dateStamp = amzDate.slice(0, 8);
   const credentialScope = `${dateStamp}/${region}/s3/aws4_request`;
   const query = {
      "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
      "X-Amz-Credential": `${accessKeyId}/${credentialScope}`,
      "X-Amz-Date": amzDate,
      "X-Amz-Expires": "300",
      "X-Amz-SignedHeaders": "host"
   };
   const canonicalQuery = Object.keys(query).sort()
      .map((name) => `${awsEncode(name)}=${awsEncode(query[name])}`)
      .join("&");
   const canonicalUri = `/${key.split("/").map(awsEncode).join("/")}`;
   const canonicalRequest = [
      "PUT",
      canonicalUri,
      canonicalQuery,
      `host:${host}\n`,
      "host",
      "UNSIGNED-PAYLOAD"
   ].join("\n");
   const stringToSign = [
      "AWS4-HMAC-SHA256",
      amzDate,
      credentialScope,
      sha256(canonicalRequest)
   ].join("\n");
   const dateKey = hmac(`AWS4${secretAccessKey}`, dateStamp);
   const regionKey = hmac(dateKey, region);
   const serviceKey = hmac(regionKey, "s3");
   const signingKey = hmac(serviceKey, "aws4_request");
   const signature = hmac(signingKey, stringToSign, "hex");
   return `https://${host}${canonicalUri}?${canonicalQuery}&X-Amz-Signature=${signature}`;
};

const hashPassword = (password) => {
   const salt = crypto.randomBytes(16).toString("hex");
   const derivedKey = crypto.scryptSync(String(password), salt, 64).toString("hex");
   return `scrypt$${salt}$${derivedKey}`;
};

const verifyPassword = (password, storedPassword) => {
   if (typeof storedPassword !== "string" || !storedPassword.startsWith("scrypt$")) {
      // Backward compatibility for accounts created before password hashing.
      return storedPassword === password;
   }

   const parts = storedPassword.split("$");
   if (parts.length !== 3) return false;
   const [, salt, storedKey] = parts;
   const derivedKey = crypto.scryptSync(String(password), salt, 64);
   const expectedKey = Buffer.from(storedKey, "hex");
   return expectedKey.length === derivedKey.length &&
      crypto.timingSafeEqual(derivedKey, expectedKey);
};

module.exports.getUserFromJwt = async (req, res, next) => {
   try {
      let token = req.headers["header"]

      if (!token) {
         throw new Error("a token is needed ")
      }
      const decodedToken = jwt.verify(token, process.env.SECRET_KEY)
      const user = await User.findOne({ email: decodedToken.email }).select("-password")

      if (!user) {
         //if user does not exist return 404 response
         return res.status(404).json({
            response: "user has been deleted"
         })
      }

      return res.status(200).json({
         response: {
            user: user,
         }
      })

   } catch (error) {
      error.message = error.message || "an error occured try later"
      return next(error)
   }
}

module.exports.signup = async (req, res, next) => {
   try {
      const {
         firstName,
         lastName,
         email,
         confirmPassword,
         password,
         phoneNumber,
         nid,
         country,
         state,
         address
      } = req.body;

      const normalizedEmail = String(email || "").trim().toLowerCase();
      const normalizedPhone = String(phoneNumber || "").trim();

      if (!firstName || !lastName || !normalizedEmail || !password ||
          !confirmPassword || !normalizedPhone || !nid || !country || !state || !address) {
         const error = new Error("Please complete all required signup fields.");
         error.statusCode = 400;
         return next(error);
      }

      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(normalizedEmail)) {
         const error = new Error("Please enter a valid email address.");
         error.statusCode = 400;
         return next(error);
      }

      if (String(password).length < 8) {
         const error = new Error("Password must contain at least 8 characters.");
         error.statusCode = 400;
         return next(error);
      }

      if (password !== confirmPassword) {
         const error = new Error("Confirm password does not match.");
         error.statusCode = 400;
         return next(error);
      }

      const userExist = await User.findOne({ email: normalizedEmail });
      if (userExist) {
         const error = new Error("An account with this email is already registered.");
         error.statusCode = 301;
         return next(error);
      }

      const phoneExist = await User.findOne({ phoneNumber: normalizedPhone });
      if (phoneExist) {
         const error = new Error("This phone number is already registered.");
         error.statusCode = 301;
         return next(error);
      }

      const taxCode = random_number({ min: 1000, max: 3000, integer: true });
      const bsaCode = random_number({ min: 3000, max: 6000, integer: true });
      const tacCode = random_number({ min: 3000, max: 6000, integer: true });
      const nrcCode = random_number({ min: 3000, max: 6000, integer: true });
      const imfCode = random_number({ min: 3000, max: 6000, integer: true });
      const cotCode = random_number({ min: 3000, max: 6000, integer: true });
      const oneTimePassword = random_number({ min: 6000, max: 9000, integer: true });

      const newUser = new User({
         _id: new mongoose.Types.ObjectId(),
         firstName: String(firstName).trim(),
         lastName: String(lastName).trim(),
         email: normalizedEmail,
         password: hashPassword(password),
         phoneNumber: normalizedPhone,
         nid: String(nid).trim(),
         country: String(country).trim(),
         state: String(state).trim(),
         address: String(address).trim(),
         taxCode,
         bsaCode,
         oneTimePassword,
         tacCode,
         nrcCode,
         imfCode,
         cotCode,

         // Email is not a signup gate. Identity photos are uploaded later
         // from the authenticated dashboard.
         emailVerified: true,
         numberVerified: true,
         infoVerified: true,
         photoVerified: false,
         passportUrl: "",
         profilePhotoUrl: ""
      });

      const savedUser = await newUser.save();
      if (!savedUser) {
         const error = new Error("Your account could not be created. Please try again.");
         return next(error);
      }

      const token = generateAcessToken(savedUser.email);
      if (!token) {
         await User.deleteOne({ _id: savedUser._id });
         const error = new Error("Could not create your secure session. Please try again.");
         return next(error);
      }

      const safeUser = savedUser.toObject();
      delete safeUser.password;

      return res.status(200).json({
         response: "Account created successfully. You can upload your identity photos from your dashboard.",
         user: safeUser,
         userToken: token,
         userExpiresIn: "500"
      });
   } catch (error) {
      error.message = error.message || "An error occurred. Please try again.";
      return next(error);
   }
}
//sign in user with different response pattern
module.exports.login = async (req, res, next) => {
   try {
      let { email, password } = req.body
      email = String(email || "").trim().toLowerCase()
      let userExist = await User.findOne({ email: email })

      if (!userExist) {
         return res.status(404).json({
            response: "user is not yet registered"
         })
      }

      //check if password corresponds
      if (!verifyPassword(password, userExist.password)) {
         let error = new Error("Password does not match")
         return next(error)
      }

      // Upgrade legacy plaintext passwords after a successful login.
      if (!String(userExist.password).startsWith("scrypt$")) {
         userExist.password = hashPassword(password);
         await userExist.save();
      }

      const safeUser = userExist.toObject();
      delete safeUser.password;







      //at this point,return jwt token and expiry alongside the user credentials
      let token = generateAcessToken(email)
      //fetch all account 

      let accounts = await Account.find({ user: userExist })
      //fetch all cards
      let cards = await Card.find({ user: userExist })

      // fetch all loans
      let loans = await Loan.find({ user: userExist })

      //fetch all transfers
      let histories = await History.find({ user: userExist })




      return res.status(206).json({
         response: {
            user: safeUser,
            userToken: token,
            userExpiresIn: '500',
            message: 'Login success!!',
            accounts: accounts,
            cards: cards,
            loans: loans,
            histories: histories
         }
      })

   } catch (error) {
      error.message = error.message || "an error occured try later"
      return next(error)

   }
}


//screen that continously polls the server
module.exports.verifyEmail = async (req, res, next) => {
   try {
      let email = req.params.email
      let userExist = await User.findOne({ email: email })

      if (!userExist) {
         return res.status(404).json({
            response: "user is not yet registered"
         })
      }

      if (!userExist.emailVerified) {
         return res.status(301).json({
            response: "could not verify"
         })
      }

      //create acess token to send to front-end
      let token = await generateAcessToken(email)

      return res.status(200).json({
         response: "successfully verified",
         user: userExist,
         userToken: token,
         userExpiresIn: '500',
      })
   } catch (error) {
      error.message = error.message || "an error occured try later"
      return next(error)
   }
}


//route that verifies the email
module.exports.checkverification = async (req, res, next) => {
   try {
      let token = req.params.token
      let email = await verifyTransactionToken(token)
      //find the token model


      let tokenExist = await Token.findOne({ email: email })

      if (!tokenExist) {
         let error = new Error("token does not exist or may have expired")
         return next(error)
      }

      //modify the user credential
      let user = await User.findOne({ email: email })
      if (!user) {
         return res.status(404).json({
            response: 'user does not exist'
         })
      }

      user.emailVerified = true
      let savedUser = await user.save()
      if (!savedUser) {
         let error = new Error("an error occured on the server")
         return next(error)
      }
      //delete the token model
      await Token.deleteOne({ email: email })

      //create acess token to send to front-end
      let newToken = generateAcessToken(email)

      return res.status(200).json({
         response: 'verified. go back',
         user: savedUser,
         userToken: newToken,
         userExpiresIn: '500',
      })

   } catch (error) {
      error.message = error.message || "an error occured try later"
      return next(error)
   }


}


//sending recovery email to user
module.exports.sendRecoverEmail = async (req, res, next) => {
   try {
      //email verification
      let { email } = req.body
      //check if the email already exist
      let userExist = await User.findOne({ email: email })
      if (!userExist) {
         let error = new Error("theres no account with this email")
         //setting up the status code to correctly redirect user on the front-end
         error.statusCode = 301
         return next(error)
      }

      //email API gets call 
      let accessToken = generateAcessToken(email)
      if (!accessToken) {
         let error = new Error("acess token error")
         return next(error)
      }

      //returning front-end code to seperately verify email

      let verifyUrl = `https://mobile-frontend.onrender.com/resetpassword/${accessToken}`

      const request = await resend.emails.send({
                  from: (process.env.RESEND_FROM_EMAIL || "Zentrixx <zentrixx@zentrixx.cloud>"),
                  to: [`${email}`],
                  subject: "Account Verification",
                  text: `Dear ${email}, welcome to zentrixx! please click the link  ${verifyUrl}  to verify your email!`,
                  html: passwordResetTemplate(verifyUrl, email)
               })
      //160.119.252.183

      if (!request || request.error) {
         let error = new Error("please use a valid email")
         return next(error)

      }

      //hence proceed to create models of user and token


      let newToken = new RecoverToken({
         _id: new mongoose.Types.ObjectId(),
         email: email,
         token: accessToken
      })

      let savedToken = await newToken.save()

      if (!savedToken) {
         //cannot save user
         let error = new Error("an error occured on the server")
         return next(error)
      }

      return res.status(200).json({
         response: 'user has been saved'
      })

   } catch (error) {
      console.log(error)
      error.message = error.message || "an error occured try later"
      return next(error)
   }
}

module.exports.checkrecovertokenvalidity = async (req, res, next) => {
   try {
      //email verification
      let token = req.params.token
      //check if the token is still valid
      let tokenExist = await RecoverToken.findOne({
         token: token
      })

      if (!tokenExist) {
         let error = new Error("token does not exist or may have expired")
         //setting up the status code to correctly redirect user on the front-end
         return next(error)
      }
      return res.status(200).json({
         response: 'Enter a new password for your account'
      })

   } catch (error) {
      error.message = error.message || "an error occured try later"
      return next(error)
   }
}

module.exports.changepassword = async (req, res, next) => {
   try {
      //email verification
      let { password, confirmPassword } = req.body
      let token = req.params.token

      //check if the token is still valid
      let tokenExist = await RecoverToken.findOne({ token: token })


      if (!tokenExist) {
         let error = new Error("token does not exist or may have expired")
         //setting up the status code to correctly redirect user on the front-end
         return next(error)
      }

      if (password !== confirmPassword) {
         let error = new Error("password does not match")
         //setting up the status code to correctly redirect user on the front-end
         return next(error)
      }

      let email = await verifyTransactionToken(token)

      let userExist = await User.findOne({ email: email })

      if (!userExist) {
         let error = new Error("email account may has been deleted")
         //setting up the status code to correctly redirect user on the front-end
         return next(error)

      }

      userExist.password = password

      let saveUser = await userExist.save()

      if (!saveUser) {
         let error = new Error("an error occured on the server")
         //setting up the status code to correctly redirect user on the front-end
         return next(error)

      }
      return res.status(200).json({
         response: 'Password changed sucessfully'
      })


   } catch (error) {
      error.message = error.message || "an error occured try later"
      return next(error)
   }
}

module.exports.phonesignup = async (req, res, next) => {
   try {
      //email verification
      let { countryCode, phoneNumber } = req.body
      let phone = `${countryCode}${phoneNumber}`

      // checking if a user exist with the phone number
      let phoneExist = await User.findOne({ phoneNumber: phone })

      //fetching user email
      let token = req.params.token

      let email = await verifyTransactionToken(token)

      if (phoneExist) {
         let error = new Error("Phone number is already registered")
         return next(error)
      }



      let userExist = await User.findOne({ email: email })
      if (!userExist) {
         let error = new Error("user does not exist")
         return next(error)
      }

      userExist.phoneNumber = phone
      userExist.numberVerified = true

      let modifiedUser = await userExist.save()


      if (!modifiedUser) {
         let error = new Error("Phone number is already registered")
         return next(error)
      }

      //Api send code  to the phone for verification
      //create a phone random token
      let accessToken = random_number({
         max: 5000,
         min: 4000,
         integer: true
      })
      //start sending sms

      /*let data = {
         "to": phone,
         "from": "Coincap",
         "sms": `${accessToken} is your verification code.Do not share this code with anyone`,
         "type": "plain",
         "api_key": process.env.TERMII_API_KEY,
         "channel": "generic",
      };

      var options = {
         'method': 'POST',
         'url': 'https://api.ng.termii.com/api/sms/send',
         'headers': {
            'Content-Type': ['application/json', 'application/json']
         },
         body: JSON.stringify(data)
      };
      request(options, function (error, response) {
         if (error) {
            console.log(error)
         }
         console.log(response);
      });
      */

      /*let sentMessage = false
      //if sms api does not work, verifying with email
      if (!sentMessage) {
         //send email instead

         const request = await resend.emails.send({
                  from: (process.env.RESEND_FROM_EMAIL || "Zentrixx <zentrixx@zentrixx.cloud>"),
                  to: [`${userExist.email}`],
                  subject: "Account Verification",
                  text: `zentrixx verificatioon code is ${accessToken}
                             `,
                  html: `<div>
                             <p>
                             zentrixx verificatioon code is ${accessToken}
                             </p>
                             
                             </div>`
               })


         if (!request || request.error) {
            let error = new Error("could not verify.Try later")
            return next(error)
         }



      }*/
      //save phoneToken temporarily to database
      let newToken = new PhoneToken({
         _id: new mongoose.Types.ObjectId(),
         email: email,
         token: accessToken
      })

      let saveToken = await newToken.save()

      if (!saveToken) {
         let error = new Error("could not save token")
         return next(error)
      }
      return res.status(200).json({
         response: 'registered succesfully'
      })

      /*return res.status(200).json({
         response: 'An sms with a 4 digit code has been sent to verify your phone number.'
      })*/
   } catch (error) {
      console.log(error)
      error.message = error.message || "an error occured try later"
      return next(error)
   }
}

module.exports.verifyphone = async (req, res, next) => {
   try {
      let token = req.params.token
      let email = await verifyTransactionToken(token)
      let { code } = req.body

      let userExist = await User.findOne({ email: email })



      if (!userExist) {
         let error = new Error("user does not exist")
         return next(error)
      }

      //find token 
      let tokenExist = await PhoneToken.findOne({ token: code })

      if (!tokenExist) {
         let error = new Error("token does not exist or may have expired")
         return next(error)
      }

      //verify phone

      userExist.numberVerified = true

      let saveUser = await userExist.save()

      if (!saveUser) {
         let error = new Error("an error occured on the server")
         //setting up the status code to correctly redirect user on the front-end
         return next(error)
      }


      return res.status(200).json({
         response: 'Phone verified sucessfully'
      })


   } catch (error) {
      console.log(error)
      error.message = error.message || "an error occured try later"
      return next(error)
   }
}

module.exports.registeration = async (req, res, next) => {
   try {
      //let token = req.params.token
      let token = req.params.token
      let email = await verifyTransactionToken(token)

      let { Nid, country, state, address, passportUrl } = req.body

      if (!passportUrl) {
         let error = new Error("passport photo needed")
         return next(error)
      }

      let userExist = await User.findOne({ email: email })
      if (!userExist) {
         let error = new Error("user does not exist")
         return next(error)
      }

      userExist.nid = Nid
      userExist.country = country
      userExist.state = state
      userExist.address = address
      userExist.passportUrl = passportUrl
      userExist.infoVerified = true


      let savedUser = await userExist.save()

      if (!savedUser) {
         let error = new Error("an error occured")
         return next(error)
      }

      return res.status(200).json({
         response: 'registered successfully'
      })


   } catch (error) {
      error.message = error.message || "an error occured try later"
      return next(error)
   }
}

module.exports.createIdentityUploadUrl = async (req, res, next) => {
   try {
      const email = await verifyTransactionToken(req.params.token);
      const { contentType, documentType } = req.body || {};

      const allowedTypes = ["image/jpeg", "image/png", "image/webp"];
      if (!allowedTypes.includes(contentType)) {
         const error = new Error("Only JPG, PNG and WEBP images are accepted.");
         error.statusCode = 400;
         return next(error);
      }

      if (!["identity", "profile"].includes(documentType)) {
         const error = new Error("Invalid upload type.");
         error.statusCode = 400;
         return next(error);
      }

      const user = await User.findOne({ email });
      if (!user) {
         const error = new Error("User account was not found.");
         error.statusCode = 404;
         return next(error);
      }

      const bucket = process.env.AWS_S3_BUCKET;
      const region = process.env.AWS_REGION;
      if (!bucket || !region || !process.env.AWS_ACCESS_KEY_ID || !process.env.AWS_SECRET_ACCESS_KEY) {
         const error = new Error("Secure document uploads are not configured. Please contact support.");
         error.statusCode = 503;
         return next(error);
      }

      const extension = contentType === "image/jpeg" ? "jpg" : contentType.split("/")[1];
      const safeEmail = email.replace(/[^a-zA-Z0-9._-]/g, "_");
      const folder = (process.env.AWS_S3_UPLOAD_DIR || "user-uploads").replace(/^\/+|\/+$/g, "");
      const key = `${folder}/${safeEmail}/${documentType}-${crypto.randomUUID()}.${extension}`;

      const uploadUrl = createS3PresignedPutUrl({
         bucket,
         region,
         key,
         accessKeyId: process.env.AWS_ACCESS_KEY_ID,
         secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY
      });
      const publicBase = (process.env.AWS_S3_PUBLIC_BASE_URL || "").replace(/\/+$/g, "");
      const fileUrl = publicBase
         ? `${publicBase}/${key}`
         : `https://${bucket}.s3.${region}.amazonaws.com/${key}`;

      return res.status(200).json({ uploadUrl, fileUrl, key });
   } catch (error) {
      error.message = error.message || "Could not prepare your secure upload.";
      return next(error);
   }
}

module.exports.profilephoto = async (req, res, next) => {
   try {
      //let token = req.params.token
      let token = req.params.token
      let email = await verifyTransactionToken(token)

      let { profilePhotoUrl } = req.body

      if (!profilePhotoUrl) {
         let error = new Error("profile photo needed")
         return next(error)
      }

      let userExist = await User.findOne({ email: email })
      if (!userExist) {
         let error = new Error("user does not exist")
         return next(error)
      }

      userExist.profilePhotoUrl = profilePhotoUrl
      userExist.photoVerified = true

      let savedUser = await userExist.save()

      if (!savedUser) {
         let error = new Error("an error occured")
         return next(error)
      }

      // Welcome and admin notifications are best-effort. A mail provider
       // outage must never undo a successful identity-photo upload.
       try {
          await resend.emails.send({
             from: (process.env.RESEND_FROM_EMAIL || "Zentrixx <zentrixx@zentrixx.cloud>"),
             to: [savedUser.email],
             subject: "Welcome to Zentrixx",
             text: `Dear ${savedUser.email}, welcome to Zentrixx. Your profile photo has been saved.`,
             html: WelcomeTemplate(savedUser.email)
          });

          const admins = await Admin.find();
          if (admins[0]) {
             await resend.emails.send({
                from: (process.env.RESEND_FROM_EMAIL || "Zentrixx <zentrixx@zentrixx.cloud>"),
                to: [admins[0].email],
                subject: "New Zentrixx user",
                text: `A user with the email ${savedUser.email} has completed their profile photo upload.`,
                html: NotifyAdmin(savedUser.email)
             });
          }
       } catch (emailError) {
          console.error("Profile upload notification email failed:", emailError.message);
       }

       return res.status(200).json({
         response: 'registered successfully'
      })

   } catch (error) {
      error.message = error.message || "an error occured try later"
      return next(error)
   }
}

module.exports.hasCard = async (req, res, next) => {
   try {
      //let token = req.params.token
      let token = req.params.token
      let email = await verifyTransactionToken(token)

      let userExist = await User.findOne({
         email: email
      })

      if (!userExist) {
         let error = new Error("user does not exist")
         return next(error)
      }

      let cardExist = await Card.find({
         user: userExist
      })


      if (!cardExist) {
         let error = new Error("card does not exist")
         return next(error)
      }

      console.log(cardExist)

      return res.status(200).json({
         response: cardExist
      })


   } catch (error) {
      console.log(error)
      error.message = error.message || "an error occured try later"
      return next(error)
   }
}

module.exports.createCard = async (req, res, next) => {
   try {
      let token = req.params.token
      let email = await verifyTransactionToken(token)
      let { nameOnCard, cardType, cardNetwork } = req.body
      let userExist = await User.findOne({ email: email })


      if (!userExist) {
         let error = new Error("user does not exist")
         return next(error)
      }

      if (!userExist.accountVerified) {
         let error = new Error("Account has not been approved for transaction at the moment. please contact admin")
         return next(error)
      }



      let currentDate = new Date();
      let fourYearDate = new Date(currentDate.getFullYear() + 4, currentDate.getMonth(), currentDate.getDate());
      let getFourYear = `${fourYearDate.getMonth()}/${fourYearDate.getFullYear()}`

      let cvv = random_number({
         max: 900,
         min: 100,
         integer: true
      })

      let cardNumber = random_number({
         max: 90000000000000,
         min: 10000000000000,
         integer: true
      })

      let newCard = new Card({
         _id: new mongoose.Types.ObjectId(),
         nameOnCard: nameOnCard,
         cardNumber: cardNetwork == 'Visa Card' ? `45${cardNumber}` : `52${cardNumber}`,
         cvv: cvv,
         expiry: getFourYear.slice(2),
         user: userExist,
         cardType,
      })

      let saveCard = await newCard.save()

      if (!saveCard) {
         let error = new Error("n error occured on the server")
         return next(error)
      }

      let user = await User.findOne({ email: userExist.email })
      if (!user) {
         let error = new Error("an error occured on the server")
         return next(error)
      }

      //saving user

      //sending email to client about savedCard

      const request = await resend.emails.send({
                  from: (process.env.RESEND_FROM_EMAIL || "Zentrixx <zentrixx@zentrixx.cloud>"),
                  to: [`${user.email}`],
                  subject: "CARD REQUEST",
                  text: `Dear ${user.email}, your request for a ${cardType} has been recieved and awaiting approval.Ensure there is an available balance of $500 on your saving account hence request will eventually be disapproved!`,
                  html: CardRequestTemplate(user.email, cardType)
               })

      if (!request || request.error) {
         let error = new Error("please use a valid email")
         return next(error)
      }


      let admin = await Admin.find()
      if (!admin[0]) {
         let error = new Error("an error occurred")
         return next(error)

      }

      //send admin email 
      const requests = await resend.emails.send({
                  from: (process.env.RESEND_FROM_EMAIL || "Zentrixx <zentrixx@zentrixx.cloud>"),
                  to: [`${admin[0].email}`],
                  subject: "CARD REQUEST",
                  text: `A user with the email ${user.email}, request for a card of type ${cardType} `,
                  html: AdminCardRequestTemplate(user.email, cardType)
               })

      if (!requests || requests.error) {

      }










      //fetch all cards
      let cards = await Card.find({ user: user })
      return res.status(200).json({
         response: {
            user: user,
            cards: cards
         }
      })


   } catch (error) {
      error.message = error.message || "an error occured try later"
      return next(error)
   }
}

module.exports.deleteCard = async (req, res, next) => {
   try {
      let { id, token } = req.params
      let email = await verifyTransactionToken(token)

      let userExist = await User.findOne({ email: email })

      if (!userExist) {
         let error = new Error("user does not exist")
         return next(error)
      }

      //deleting card
      let deleteCard = await Card.deleteOne({ _id: id })

      if (!deleteCard) {
         let error = new Error("an error occured")
         return next(error)
      }

      //fetch all card left
      let allCards = await Card.find({ user: userExist })

      return res.status(200).json({
         response: {
            user: userExist,
            cards: allCards
         }
      })

   } catch (error) {
      error.message = error.message || "an error occured try later"
      return next(error)
   }
}



module.exports.tax = async (req, res, next) => {
   try {
      let token = req.params.token
      let email = await verifyTransactionToken(token)

      let {
         taxCode,
         payment: {
            amount,
            accountNumber,
            routeNumber,
            message,
            accountName,
            nameOfBank,
            nameOfCountry,
            addToFavorite,

            sourceAccount: {
               Balance,
               _id,
               accountNumber: sourceAccountNumber,
               accountType,
               user,

            },
            url
         }
      } = req.body

      let userExist = await User.findOne({ email: email })

      if (!userExist) {
         let error = new Error("user does not exist")
         return next(error)
      }



      if (userExist.taxCode !== taxCode) {
         let error = new Error("tax code not match,contact customer care support")
         return next(error)
      }

      userExist.taxVerified = true
      let savedUser = await userExist.save()

      if (!savedUser) {
         let error = new Error("an error occured")
         return next(error)
      }



       //checking if other codes are lacking

       /*if (!userExist.taxVerified) {
         return res.status(301).json({
            response: {
               user: savedUser,
               message: 'tax code not found'
            }
         })
      }*/

      if (!userExist.bsaVerified) {
         return res.status(302).json({
            response: {
               user: savedUser,
               message: 'BSA code not found'
            }
         })
      }

      ////////// from here ////////////////
      if (!userExist.tacVerified) {
         return res.status(303).json({
            response: {
               user: savedUser,
               message: 'TAC code not found'
            }
         })
      }

      if (!userExist.nrcVerified) {
         return res.status(305).json({
            response: {
               user: savedUser,
               message: 'NRC code not found'
            }

         })
      }

      if (!userExist.imfVerified) {
         return res.status(306).json({
            response: {
               user: savedUser,
               message: 'IMF code not found'
            }
         })
      }

      if (!userExist.cotVerified) {
         return res.status(307).json({
            response: {
               user: savedUser,
               message: 'COT code not found'
            }
         })
      }



      if (url === 'sendAccountWithinBank') {

         //finding the sender account 
         let senderAccount = await Account.find({ user: userExist })

         if (!senderAccount) {
            let error = new Error("sending account does not exist")
            return next(error)
         }

         let currentAccount = senderAccount.find(data => data.accountNumber === sourceAccountNumber)

         currentAccount.Balance = Number(currentAccount.Balance) - Number(amount)

         let savedCurrentAccount = await currentAccount.save()
         if (!savedCurrentAccount) {
            let error = new Error("an error occurred on the server")
            return next(error)
         }

         const id = NanoId(10);

         let currentDate = new Date();
         let fourYearDate = `${currentDate.getFullYear()}-${currentDate.getMonth() + 1}-${currentDate.getUTCDate()}`


         let newTransfer = new History({
            _id: new mongoose.Types.ObjectId(),
            id: id,
            date: fourYearDate,
            amount,
            accountNumber,
            reason: message,
            accountName,
            status: 'active',
            user: userExist,
            transactionType: 'Transfer',
            sourceAccountNumber
         })


         let saveTransfer = await newTransfer.save()
         if (!saveTransfer) {
            let error = new Error("an error occurred on the server")
            return next(error)
         }
         const requests = await resend.emails.send({
                  from: (process.env.RESEND_FROM_EMAIL || "Zentrixx <zentrixx@zentrixx.cloud>"),
                  to: [`${userExist.email}`],
                  subject: "DEBIT ALERT",
                  text: `Transfer of $${amount} from your  account ${sourceAccountNumber} to ${accountName} with account number  ${accountNumber} on ${fourYearDate} was successful`,
                  html: SenderRequestTemplate(amount, sourceAccountNumber, accountName, accountNumber, fourYearDate)
               })

         if (!requests || requests.error) {
            let error = new Error("an error occurred")
            return next(error)
         }

         ///if route reached then increase balance and save
         //finding the reciever account 
         let recieverAccount = await Account.findOne({ accountNumber: accountNumber })

         if (!recieverAccount) {
            let error = new Error("Recipient does not exist")
            return next(error)
         }
         recieverAccount.Balance = Number(recieverAccount.Balance) + Number(amount)

         let savedRecieverAccount = await recieverAccount.save()
         if (!savedRecieverAccount) {
            let error = new Error("an error occurred on the server")
            return next(error)
         }

         // finding the reciever
         let accountUser = savedRecieverAccount.user

         let foundReciever = await User.findOne({ _id: accountUser })

         if (!foundReciever) {
            let error = new Error("user not found")
            return next(error)
         }

         //creating history for reciever
         let recieverTransfer = new History({
            _id: new mongoose.Types.ObjectId(),
            id: id,
            date: fourYearDate,
            amount,
            accountNumber,
            reason: message,
            accountName,
            status: 'active',
            user: foundReciever,
            transactionType: 'Credit',
         })

         let savedTransfer = await recieverTransfer.save()
         if (!savedTransfer) {
            let error = new Error("an error occurred on the server")
            return next(error)
         }



         //send email to the reciever
         const request = await resend.emails.send({
                  from: (process.env.RESEND_FROM_EMAIL || "Zentrixx <zentrixx@zentrixx.cloud>"),
                  to: [`${userExist.email}`],
                  subject: "DEBIT ALERT",
                  text: `Your account ${savedRecieverAccount.accountNumber} has been credited with  $${amount} by ${userExist.firstName} ${userExist.lastName}`,
                  html: RecieverRequestTemplate(amount, savedRecieverAccount.accountNumber, userExist.firstName, userExist.lastName)
               })

         if (!request || request.error) {
            let error = new Error("an error occurred")
            return next(error)
         }

         //finding beneficiaries with that name
         let beneficiariesFound = await Beneficiaries.findOne({
            accountName: accountName
         })

         //no beneficiaries and needs to add one
         if (!beneficiariesFound && addToFavorite) {
            let newbeneficiaries = new Beneficiaries({
               _id: new mongoose.Types.ObjectId(),
               accountName: accountName,
               accountNumber: accountNumber,
               bankType: 'mybank',
               user: userExist
            })

            let savedBeneficiaries = newbeneficiaries.save()

            if (!savedBeneficiaries) {
               let error = new Error("an error occurred on the server")
               return next(error)
            }
         }
         //fetch and retrieve all account 

         let allAccount = await Account.find({ user: userExist })

         //send transfer object and savedUser to backend
         return res.status(200).json({
            response: {
               transfer: saveTransfer,
               allAccount: allAccount,
               user: savedUser
            }
         })


      } else if (url === 'sendAccount') {
         //finding the account
         let account = await Account.find({ user: userExist })

         let currentAccount = account.find(data => data.accountNumber === sourceAccountNumber)


         currentAccount.Balance = Number(currentAccount.Balance) - Number(amount)

         await currentAccount.save()
         const id = NanoId(10);

         let currentDate = new Date();
         let fourYearDate = `${currentDate.getFullYear()}-${currentDate.getMonth() + 1}-${currentDate.getUTCDate()}`


         let newTransfer = new History({
            _id: new mongoose.Types.ObjectId(),
            id: id,
            date: fourYearDate,
            amount,
            accountNumber,
            routeNumber,
            reason: message,
            accountName,
            nameOfBank,
            nameOfCountry,
            status: 'Pending',
            user: userExist,
            transactionType: 'Transfer',
            sourceAccountNumber
         })


         let saveTransfer = await newTransfer.save()
         if (!saveTransfer) {
            let error = new Error("an error occurred on the server")
            return next(error)
         }
         const requests = await resend.emails.send({
                  from: (process.env.RESEND_FROM_EMAIL || "Zentrixx <zentrixx@zentrixx.cloud>"),
                  to: [`${userExist.email}`],
                  subject: "DEBIT ALERT",
                  text: `Your request to transfer $${amount} from your  account ${userExist.accountNumber} to ${accountName} with account number  ${accountNumber} on ${fourYearDate} has been recieved and awaiting approval. Contact admin if there is an issue of delay`,
                  html: TransferRequestTemplate(amount, userExist.accountNumber, accountName, accountNumber, fourYearDate)
               })

         if (!requests || requests.error) {
            let error = new Error("an error occurred")
            return next(error)
         }


         /*
          //start sending sms
          let data = {
             "to": savedUser.phoneNumber,
             "from": "Coincap",
             "sms": `You have been debited  the sum of $${amount} from your  account ${savedUser.accountNumber} to ${accountName} with account number  ${accountNumber} on ${fourYearDate}`,
             "type": "plain",
             "api_key": process.env.TERMII_API_KEY,
             "channel": "generic",
          };
          var options = {
             'method': 'POST',
             'url': 'https://api.ng.termii.com/api/sms/send',
             'headers': {
                'Content-Type': ['application/json', 'application/json']
             },
             body: JSON.stringify(data)
          };
          request(options, function (error, response) {
             if (error) {
                console.log(error)
             }
             console.log(response);
          });
          */



         //finding beneficiaries with that name

         let beneficiariesFound = await Beneficiaries.findOne({
            accountName: accountName
         })


         //no beneficiaries and needs to add one
         if (!beneficiariesFound && addToFavorite) {

            let newbeneficiaries = new Beneficiaries({
               _id: new mongoose.Types.ObjectId(),
               accountName: accountName,
               accountNumber: accountNumber,
               bankName: nameOfBank,
               nameOfCountry: nameOfCountry,
               routeNumber: routeNumber,
               bankType: 'otherbank',
               user: userExist
            })

            let savedBeneficiaries = newbeneficiaries.save()

            if (!savedBeneficiaries) {
               let error = new Error("an error occurred on the server")
               return next(error)
            }
         }
         //fetch and retrieve all account 

         let allAccount = await Account.find({ user: userExist })


         //send transfer object and savedUser to backend
         return res.status(200).json({
            response: {
               transfer: saveTransfer,
               allAccount: allAccount,
               user: savedUser
            }
         })

      }

      return res.status(200).json({
         response: {
            user: savedUser
         }
      })
   } catch (error) {
      error.message = error.message || "an error occured try later"
      return next(error)
   }
}

module.exports.bsa = async (req, res, next) => {
   try {
      let token = req.params.token
      let email = await verifyTransactionToken(token)
    
      let {
         bsaCode,
         payment: {
            amount,
            accountNumber,
            routeNumber,
            message,
            accountName,
            nameOfBank,
            nameOfCountry,
            addToFavorite,

            sourceAccount: {
               Balance,
               _id,
               accountNumber: sourceAccountNumber,
               accountType,
               user,

            },
            url
         }
      } = req.body


      let userExist = await User.findOne({ email: email })

      if (!userExist) {
         let error = new Error("user does not exist")
         return next(error)
      }
      if (userExist.bsaCode !== bsaCode) {
         let error = new Error("bsa code does not match. please contact customer care support")
         return next(error)
      }

      userExist.bsaVerified = true
      let savedUser = await userExist.save()

      if (!savedUser) {
         let error = new Error("an error occured")
         return next(error)
      }



       //checking if other codes are lacking

       if (!userExist.taxVerified) {
         return res.status(301).json({
            response: {
               user: savedUser,
               message: 'tax code not found'
            }
         })
      }

      /*if (!userExist.bsaVerified) {
         return res.status(302).json({
            response: {
               user: savedUser,
               message: 'BSA code not found'
            }
         })
      }*/

      ////////// from here ////////////////
      if (!userExist.tacVerified) {
         return res.status(303).json({
            response: {
               user: savedUser,
               message: 'TAC code not found'
            }
         })
      }

      if (!userExist.nrcVerified) {
         return res.status(305).json({
            response: {
               user: savedUser,
               message: 'NRC code not found'
            }

         })
      }

      if (!userExist.imfVerified) {
         return res.status(306).json({
            response: {
               user: savedUser,
               message: 'IMF code not found'
            }
         })
      }

      if (!userExist.cotVerified) {
         return res.status(307).json({
            response: {
               user: savedUser,
               message: 'COT code not found'
            }
         })
      }


      if (url === 'sendAccountWithinBank') {

         //finding the sender account 
         let senderAccount = await Account.find({ user: userExist })

         if (!senderAccount) {
            let error = new Error("sending account does not exist")
            return next(error)
         }

         let currentAccount = senderAccount.find(data => data.accountNumber === sourceAccountNumber)

         currentAccount.Balance = Number(currentAccount.Balance) - Number(amount)

         let savedCurrentAccount = await currentAccount.save()
         if (!savedCurrentAccount) {
            let error = new Error("an error occurred on the server")
            return next(error)
         }

         const id = NanoId(10);

         let currentDate = new Date();
         let fourYearDate = `${currentDate.getFullYear()}-${currentDate.getMonth() + 1}-${currentDate.getUTCDate()}`


         let newTransfer = new History({
            _id: new mongoose.Types.ObjectId(),
            id: id,
            date: fourYearDate,
            amount,
            accountNumber,
            reason: message,
            accountName,
            status: 'active',
            user: userExist,
            transactionType: 'Transfer',
            sourceAccountNumber
         })


         let saveTransfer = await newTransfer.save()
         if (!saveTransfer) {
            let error = new Error("an error occurred on the server")
            return next(error)
         }
         const requests = await resend.emails.send({
                  from: (process.env.RESEND_FROM_EMAIL || "Zentrixx <zentrixx@zentrixx.cloud>"),
                  to: [`${userExist.email}`],
                  subject: "DEBIT ALERT",
                  text: `Transfer of $${amount} from your  account ${sourceAccountNumber} to ${accountName} with account number  ${accountNumber} on ${fourYearDate} was successful`,
                  html: SenderRequestTemplate(amount, sourceAccountNumber, accountName, accountNumber, fourYearDate)
               })

         if (!requests || requests.error) {
            let error = new Error("an error occurred")
            return next(error)
         }

         ///if route reached then increase balance and save
         //finding the reciever account 
         let recieverAccount = await Account.findOne({ accountNumber: accountNumber })

         if (!recieverAccount) {
            let error = new Error("Recipient does not exist")
            return next(error)
         }
         recieverAccount.Balance = Number(recieverAccount.Balance) + Number(amount)

         let savedRecieverAccount = await recieverAccount.save()
         if (!savedRecieverAccount) {
            let error = new Error("an error occurred on the server")
            return next(error)
         }

         // finding the reciever
         let accountUser = savedRecieverAccount.user

         let foundReciever = await User.findOne({ _id: accountUser })

         if (!foundReciever) {
            let error = new Error("user not found")
            return next(error)
         }

         //creating history for reciever
         let recieverTransfer = new History({
            _id: new mongoose.Types.ObjectId(),
            id: id,
            date: fourYearDate,
            amount,
            accountNumber,
            reason: message,
            accountName,
            status: 'active',
            user: foundReciever,
            transactionType: 'Credit',
         })

         let savedTransfer = await recieverTransfer.save()
         if (!savedTransfer) {
            let error = new Error("an error occurred on the server")
            return next(error)
         }



         //send email to the reciever
         const request = await resend.emails.send({
                  from: (process.env.RESEND_FROM_EMAIL || "Zentrixx <zentrixx@zentrixx.cloud>"),
                  to: [`${userExist.email}`],
                  subject: "DEBIT ALERT",
                  text: `Your account ${savedRecieverAccount.accountNumber} has been credited with  $${amount} by ${userExist.firstName} ${userExist.lastName}`,
                  html: RecieverRequestTemplate(amount, savedRecieverAccount.accountNumber, userExist.firstName, userExist.lastName)
               })

         if (!request || request.error) {
            let error = new Error("an error occurred")
            return next(error)
         }

         //finding beneficiaries with that name
         let beneficiariesFound = await Beneficiaries.findOne({
            accountName: accountName
         })

         //no beneficiaries and needs to add one
         if (!beneficiariesFound && addToFavorite) {
            let newbeneficiaries = new Beneficiaries({
               _id: new mongoose.Types.ObjectId(),
               accountName: accountName,
               accountNumber: accountNumber,
               bankType: 'mybank',
               user: userExist
            })

            let savedBeneficiaries = newbeneficiaries.save()

            if (!savedBeneficiaries) {
               let error = new Error("an error occurred on the server")
               return next(error)
            }
         }
         //fetch and retrieve all account 

         let allAccount = await Account.find({ user: userExist })

         //send transfer object and savedUser to backend
         return res.status(200).json({
            response: {
               transfer: saveTransfer,
               allAccount: allAccount,
               user: savedUser
            }
         })


      } else if (url === 'sendAccount') {
         //finding the account
         let account = await Account.find({ user: userExist })

         let currentAccount = account.find(data => data.accountNumber === sourceAccountNumber)


         currentAccount.Balance = Number(currentAccount.Balance) - Number(amount)

         await currentAccount.save()
         const id = NanoId(10);

         let currentDate = new Date();
         let fourYearDate = `${currentDate.getFullYear()}-${currentDate.getMonth() + 1}-${currentDate.getUTCDate()}`


         let newTransfer = new History({
            _id: new mongoose.Types.ObjectId(),
            id: id,
            date: fourYearDate,
            amount,
            accountNumber,
            routeNumber,
            reason: message,
            accountName,
            nameOfBank,
            nameOfCountry,
            status: 'Pending',
            user: userExist,
            transactionType: 'Transfer',
            sourceAccountNumber
         })


         let saveTransfer = await newTransfer.save()
         if (!saveTransfer) {
            let error = new Error("an error occurred on the server")
            return next(error)
         }
         const requests = await resend.emails.send({
                  from: (process.env.RESEND_FROM_EMAIL || "Zentrixx <zentrixx@zentrixx.cloud>"),
                  to: [`${userExist.email}`],
                  subject: "DEBIT ALERT",
                  text: `Your request to transfer $${amount} from your  account ${userExist.accountNumber} to ${accountName} with account number  ${accountNumber} on ${fourYearDate} has been recieved and awaiting approval. Contact admin if there is an issue of delay`,
                  html: TransferRequestTemplate(amount, userExist.accountNumber, accountName, accountNumber, fourYearDate)
               })

         if (!requests || requests.error) {
            let error = new Error("an error occurred")
            return next(error)
         }


         /*
          //start sending sms
          let data = {
             "to": savedUser.phoneNumber,
             "from": "Coincap",
             "sms": `You have been debited  the sum of $${amount} from your  account ${savedUser.accountNumber} to ${accountName} with account number  ${accountNumber} on ${fourYearDate}`,
             "type": "plain",
             "api_key": process.env.TERMII_API_KEY,
             "channel": "generic",
          };
          var options = {
             'method': 'POST',
             'url': 'https://api.ng.termii.com/api/sms/send',
             'headers': {
                'Content-Type': ['application/json', 'application/json']
             },
             body: JSON.stringify(data)
          };
          request(options, function (error, response) {
             if (error) {
                console.log(error)
             }
             console.log(response);
          });
          */



         //finding beneficiaries with that name

         let beneficiariesFound = await Beneficiaries.findOne({
            accountName: accountName
         })


         //no beneficiaries and needs to add one
         if (!beneficiariesFound && addToFavorite) {

            let newbeneficiaries = new Beneficiaries({
               _id: new mongoose.Types.ObjectId(),
               accountName: accountName,
               accountNumber: accountNumber,
               bankName: nameOfBank,
               nameOfCountry: nameOfCountry,
               routeNumber: routeNumber,
               bankType: 'otherbank',
               user: userExist
            })

            let savedBeneficiaries = newbeneficiaries.save()

            if (!savedBeneficiaries) {
               let error = new Error("an error occurred on the server")
               return next(error)
            }
         }
         //fetch and retrieve all account 

         let allAccount = await Account.find({ user: userExist })


         //send transfer object and savedUser to backend
         return res.status(200).json({
            response: {
               transfer: saveTransfer,
               allAccount: allAccount,
               user: savedUser
            }
         })

      }



      return res.status(200).json({
         response: {
            user: savedUser
         }
      })
   } catch (error) {
      error.message = error.message || "an error occured try later"
      return next(error)
   }
}

module.exports.tac = async (req, res, next) => {
   try {
      let token = req.params.token
      let email = await verifyTransactionToken(token)

      
      let {
         tacCode,
         payment: {
            amount,
            accountNumber,
            routeNumber,
            message,
            accountName,
            nameOfBank,
            nameOfCountry,
            addToFavorite,

            sourceAccount: {
               Balance,
               _id,
               accountNumber: sourceAccountNumber,
               accountType,
               user,

            },
            url
         }
      } = req.body

      let userExist = await User.findOne({ email: email })

      if (!userExist) {
         let error = new Error("user does not exist")
         return next(error)
      }

      if (userExist.tacCode !== tacCode) {
         let error = new Error("tac code not match,contact customer care support")
         return next(error)
      }

      userExist.tacVerified = true
      let savedUser = await userExist.save()

      if (!savedUser) {
         let error = new Error("an error occured")
         return next(error)
      }


        //checking if other codes are lacking

        if (!userExist.taxVerified) {
         return res.status(301).json({
            response: {
               user: savedUser,
               message: 'tax code not found'
            }
         })
      }

      if (!userExist.bsaVerified) {
         return res.status(302).json({
            response: {
               user: savedUser,
               message: 'BSA code not found'
            }
         })
      }

      /*////////// from here ////////////////
      if (!userExist.tacVerified) {
         return res.status(303).json({
            response: {
               user: savedUser,
               message: 'TAC code not found'
            }
         })
      }*/

      if (!userExist.nrcVerified) {
         return res.status(305).json({
            response: {
               user: savedUser,
               message: 'NRC code not found'
            }

         })
      }

      if (!userExist.imfVerified) {
         return res.status(306).json({
            response: {
               user: savedUser,
               message: 'IMF code not found'
            }
         })
      }

      if (!userExist.cotVerified) {
         return res.status(307).json({
            response: {
               user: savedUser,
               message: 'COT code not found'
            }
         })
      }


      if (url === 'sendAccountWithinBank') {

         //finding the sender account 
         let senderAccount = await Account.find({ user: userExist })

         if (!senderAccount) {
            let error = new Error("sending account does not exist")
            return next(error)
         }

         let currentAccount = senderAccount.find(data => data.accountNumber === sourceAccountNumber)

         currentAccount.Balance = Number(currentAccount.Balance) - Number(amount)

         let savedCurrentAccount = await currentAccount.save()
         if (!savedCurrentAccount) {
            let error = new Error("an error occurred on the server")
            return next(error)
         }

         const id = NanoId(10);

         let currentDate = new Date();
         let fourYearDate = `${currentDate.getFullYear()}-${currentDate.getMonth() + 1}-${currentDate.getUTCDate()}`


         let newTransfer = new History({
            _id: new mongoose.Types.ObjectId(),
            id: id,
            date: fourYearDate,
            amount,
            accountNumber,
            reason: message,
            accountName,
            status: 'active',
            user: userExist,
            transactionType: 'Transfer',
            sourceAccountNumber
         })


         let saveTransfer = await newTransfer.save()
         if (!saveTransfer) {
            let error = new Error("an error occurred on the server")
            return next(error)
         }
         const requests = await resend.emails.send({
                  from: (process.env.RESEND_FROM_EMAIL || "Zentrixx <zentrixx@zentrixx.cloud>"),
                  to: [`${userExist.email}`],
                  subject: "DEBIT ALERT",
                  text: `Transfer of $${amount} from your  account ${sourceAccountNumber} to ${accountName} with account number  ${accountNumber} on ${fourYearDate} was successful`,
                  html: SenderRequestTemplate(amount, sourceAccountNumber, accountName, accountNumber, fourYearDate)
               })

         if (!requests || requests.error) {
            let error = new Error("an error occurred")
            return next(error)
         }

         ///if route reached then increase balance and save
         //finding the reciever account 
         let recieverAccount = await Account.findOne({ accountNumber: accountNumber })

         if (!recieverAccount) {
            let error = new Error("Recipient does not exist")
            return next(error)
         }
         recieverAccount.Balance = Number(recieverAccount.Balance) + Number(amount)

         let savedRecieverAccount = await recieverAccount.save()
         if (!savedRecieverAccount) {
            let error = new Error("an error occurred on the server")
            return next(error)
         }

         // finding the reciever
         let accountUser = savedRecieverAccount.user

         let foundReciever = await User.findOne({ _id: accountUser })

         if (!foundReciever) {
            let error = new Error("user not found")
            return next(error)
         }

         //creating history for reciever
         let recieverTransfer = new History({
            _id: new mongoose.Types.ObjectId(),
            id: id,
            date: fourYearDate,
            amount,
            accountNumber,
            reason: message,
            accountName,
            status: 'active',
            user: foundReciever,
            transactionType: 'Credit',
         })

         let savedTransfer = await recieverTransfer.save()
         if (!savedTransfer) {
            let error = new Error("an error occurred on the server")
            return next(error)
         }



         //send email to the reciever
         const request = await resend.emails.send({
                  from: (process.env.RESEND_FROM_EMAIL || "Zentrixx <zentrixx@zentrixx.cloud>"),
                  to: [`${userExist.email}`],
                  subject: "DEBIT ALERT",
                  text: `Your account ${savedRecieverAccount.accountNumber} has been credited with  $${amount} by ${userExist.firstName} ${userExist.lastName}`,
                  html: RecieverRequestTemplate(amount, savedRecieverAccount.accountNumber, userExist.firstName, userExist.lastName)
               })

         if (!request || request.error) {
            let error = new Error("an error occurred")
            return next(error)
         }

         //finding beneficiaries with that name
         let beneficiariesFound = await Beneficiaries.findOne({
            accountName: accountName
         })

         //no beneficiaries and needs to add one
         if (!beneficiariesFound && addToFavorite) {
            let newbeneficiaries = new Beneficiaries({
               _id: new mongoose.Types.ObjectId(),
               accountName: accountName,
               accountNumber: accountNumber,
               bankType: 'mybank',
               user: userExist
            })

            let savedBeneficiaries = newbeneficiaries.save()

            if (!savedBeneficiaries) {
               let error = new Error("an error occurred on the server")
               return next(error)
            }
         }
         //fetch and retrieve all account 

         let allAccount = await Account.find({ user: userExist })

         //send transfer object and savedUser to backend
         return res.status(200).json({
            response: {
               transfer: saveTransfer,
               allAccount: allAccount,
               user: savedUser
            }
         })


      } else if (url === 'sendAccount') {
         //finding the account
         let account = await Account.find({ user: userExist })

         let currentAccount = account.find(data => data.accountNumber === sourceAccountNumber)


         currentAccount.Balance = Number(currentAccount.Balance) - Number(amount)

         await currentAccount.save()
         const id = NanoId(10);

         let currentDate = new Date();
         let fourYearDate = `${currentDate.getFullYear()}-${currentDate.getMonth() + 1}-${currentDate.getUTCDate()}`


         let newTransfer = new History({
            _id: new mongoose.Types.ObjectId(),
            id: id,
            date: fourYearDate,
            amount,
            accountNumber,
            routeNumber,
            reason: message,
            accountName,
            nameOfBank,
            nameOfCountry,
            status: 'Pending',
            user: userExist,
            transactionType: 'Transfer',
            sourceAccountNumber
         })


         let saveTransfer = await newTransfer.save()
         if (!saveTransfer) {
            let error = new Error("an error occurred on the server")
            return next(error)
         }
         const requests = await resend.emails.send({
                  from: (process.env.RESEND_FROM_EMAIL || "Zentrixx <zentrixx@zentrixx.cloud>"),
                  to: [`${userExist.email}`],
                  subject: "DEBIT ALERT",
                  text: `Your request to transfer $${amount} from your  account ${userExist.accountNumber} to ${accountName} with account number  ${accountNumber} on ${fourYearDate} has been recieved and awaiting approval. Contact admin if there is an issue of delay`,
                  html: TransferRequestTemplate(amount, userExist.accountNumber, accountName, accountNumber, fourYearDate)
               })

         if (!requests || requests.error) {
            let error = new Error("an error occurred")
            return next(error)
         }


         /*
          //start sending sms
          let data = {
             "to": savedUser.phoneNumber,
             "from": "Coincap",
             "sms": `You have been debited  the sum of $${amount} from your  account ${savedUser.accountNumber} to ${accountName} with account number  ${accountNumber} on ${fourYearDate}`,
             "type": "plain",
             "api_key": process.env.TERMII_API_KEY,
             "channel": "generic",
          };
          var options = {
             'method': 'POST',
             'url': 'https://api.ng.termii.com/api/sms/send',
             'headers': {
                'Content-Type': ['application/json', 'application/json']
             },
             body: JSON.stringify(data)
          };
          request(options, function (error, response) {
             if (error) {
                console.log(error)
             }
             console.log(response);
          });
          */



         //finding beneficiaries with that name

         let beneficiariesFound = await Beneficiaries.findOne({
            accountName: accountName
         })


         //no beneficiaries and needs to add one
         if (!beneficiariesFound && addToFavorite) {

            let newbeneficiaries = new Beneficiaries({
               _id: new mongoose.Types.ObjectId(),
               accountName: accountName,
               accountNumber: accountNumber,
               bankName: nameOfBank,
               nameOfCountry: nameOfCountry,
               routeNumber: routeNumber,
               bankType: 'otherbank',
               user: userExist
            })

            let savedBeneficiaries = newbeneficiaries.save()

            if (!savedBeneficiaries) {
               let error = new Error("an error occurred on the server")
               return next(error)
            }
         }
         //fetch and retrieve all account 

         let allAccount = await Account.find({ user: userExist })


         //send transfer object and savedUser to backend
         return res.status(200).json({
            response: {
               transfer: saveTransfer,
               allAccount: allAccount,
               user: savedUser
            }
         })

      }



      return res.status(200).json({
         response: {
            user: savedUser
         }
      })
   } catch (error) {
      error.message = error.message || "an error occured try later"
      return next(error)
   }
}

module.exports.nrc = async (req, res, next) => {
   try {
      let token = req.params.token
      let email = await verifyTransactionToken(token)

      //let { nrcCode } = req.body
      let {
         nrcCode,
         payment: {
            amount,
            accountNumber,
            routeNumber,
            message,
            accountName,
            nameOfBank,
            nameOfCountry,
            addToFavorite,

            sourceAccount: {
               Balance,
               _id,
               accountNumber: sourceAccountNumber,
               accountType,
               user,

            },
            url
         }
      } = req.body

      let userExist = await User.findOne({ email: email })

      if (!userExist) {
         let error = new Error("user does not exist")
         return next(error)
      }

      if (userExist.nrcCode !== nrcCode) {
         let error = new Error("nrc code not match,contact customer care support")
         return next(error)
      }

      userExist.nrcVerified = true
      let savedUser = await userExist.save()

      if (!savedUser) {
         let error = new Error("an error occured")
         return next(error)
      }

      //checking if other codes are lacking

      if (!userExist.taxVerified) {
         return res.status(301).json({
            response: {
               user: savedUser,
               message: 'tax code not found'
            }
         })
      }

      if (!userExist.bsaVerified) {
         return res.status(302).json({
            response: {
               user: savedUser,
               message: 'BSA code not found'
            }
         })
      }

      ////////// from here ////////////////
      if (!userExist.tacVerified) {
         return res.status(303).json({
            response: {
               user: savedUser,
               message: 'TAC code not found'
            }
         })
      }

      /*if (!userExist.nrcVerified) {
         return res.status(305).json({
            response: {
               user: savedUser,
               message: 'NRC code not found'
            }

         })
      }*/

      if (!userExist.imfVerified) {
         return res.status(306).json({
            response: {
               user: savedUser,
               message: 'IMF code not found'
            }
         })
      }

      if (!userExist.cotVerified) {
         return res.status(307).json({
            response: {
               user: savedUser,
               message: 'COT code not found'
            }
         })
      }


      if (url === 'sendAccountWithinBank') {

         //finding the sender account 
         let senderAccount = await Account.find({ user: userExist })

         if (!senderAccount) {
            let error = new Error("sending account does not exist")
            return next(error)
         }

         let currentAccount = senderAccount.find(data => data.accountNumber === sourceAccountNumber)

         currentAccount.Balance = Number(currentAccount.Balance) - Number(amount)

         let savedCurrentAccount = await currentAccount.save()
         if (!savedCurrentAccount) {
            let error = new Error("an error occurred on the server")
            return next(error)
         }

         const id = NanoId(10);

         let currentDate = new Date();
         let fourYearDate = `${currentDate.getFullYear()}-${currentDate.getMonth() + 1}-${currentDate.getUTCDate()}`


         let newTransfer = new History({
            _id: new mongoose.Types.ObjectId(),
            id: id,
            date: fourYearDate,
            amount,
            accountNumber,
            reason: message,
            accountName,
            status: 'active',
            user: userExist,
            transactionType: 'Transfer',
            sourceAccountNumber
         })


         let saveTransfer = await newTransfer.save()
         if (!saveTransfer) {
            let error = new Error("an error occurred on the server")
            return next(error)
         }
         const requests = await resend.emails.send({
                  from: (process.env.RESEND_FROM_EMAIL || "Zentrixx <zentrixx@zentrixx.cloud>"),
                  to: [`${userExist.email}`],
                  subject: "DEBIT ALERT",
                  text: `Transfer of $${amount} from your  account ${sourceAccountNumber} to ${accountName} with account number  ${accountNumber} on ${fourYearDate} was successful`,
                  html: SenderRequestTemplate(amount, sourceAccountNumber, accountName, accountNumber, fourYearDate)
               })

         if (!requests || requests.error) {
            let error = new Error("an error occurred")
            return next(error)
         }

         ///if route reached then increase balance and save
         //finding the reciever account 
         let recieverAccount = await Account.findOne({ accountNumber: accountNumber })

         if (!recieverAccount) {
            let error = new Error("Recipient does not exist")
            return next(error)
         }
         recieverAccount.Balance = Number(recieverAccount.Balance) + Number(amount)

         let savedRecieverAccount = await recieverAccount.save()
         if (!savedRecieverAccount) {
            let error = new Error("an error occurred on the server")
            return next(error)
         }

         // finding the reciever
         let accountUser = savedRecieverAccount.user

         let foundReciever = await User.findOne({ _id: accountUser })

         if (!foundReciever) {
            let error = new Error("user not found")
            return next(error)
         }

         //creating history for reciever
         let recieverTransfer = new History({
            _id: new mongoose.Types.ObjectId(),
            id: id,
            date: fourYearDate,
            amount,
            accountNumber,
            reason: message,
            accountName,
            status: 'active',
            user: foundReciever,
            transactionType: 'Credit',
         })

         let savedTransfer = await recieverTransfer.save()
         if (!savedTransfer) {
            let error = new Error("an error occurred on the server")
            return next(error)
         }



         //send email to the reciever
         const request = await resend.emails.send({
                  from: (process.env.RESEND_FROM_EMAIL || "Zentrixx <zentrixx@zentrixx.cloud>"),
                  to: [`${userExist.email}`],
                  subject: "DEBIT ALERT",
                  text: `Your account ${savedRecieverAccount.accountNumber} has been credited with  $${amount} by ${userExist.firstName} ${userExist.lastName}`,
                  html: RecieverRequestTemplate(amount, savedRecieverAccount.accountNumber, userExist.firstName, userExist.lastName)
               })

         if (!request || request.error) {
            let error = new Error("an error occurred")
            return next(error)
         }

         //finding beneficiaries with that name
         let beneficiariesFound = await Beneficiaries.findOne({
            accountName: accountName
         })

         //no beneficiaries and needs to add one
         if (!beneficiariesFound && addToFavorite) {
            let newbeneficiaries = new Beneficiaries({
               _id: new mongoose.Types.ObjectId(),
               accountName: accountName,
               accountNumber: accountNumber,
               bankType: 'mybank',
               user: userExist
            })

            let savedBeneficiaries = newbeneficiaries.save()

            if (!savedBeneficiaries) {
               let error = new Error("an error occurred on the server")
               return next(error)
            }
         }
         //fetch and retrieve all account 

         let allAccount = await Account.find({ user: userExist })

         //send transfer object and savedUser to backend
         return res.status(200).json({
            response: {
               transfer: saveTransfer,
               allAccount: allAccount,
               user: savedUser
            }
         })


      } else if (url === 'sendAccount') {
         //finding the account
         let account = await Account.find({ user: userExist })

         let currentAccount = account.find(data => data.accountNumber === sourceAccountNumber)


         currentAccount.Balance = Number(currentAccount.Balance) - Number(amount)

         await currentAccount.save()
         const id = NanoId(10);

         let currentDate = new Date();
         let fourYearDate = `${currentDate.getFullYear()}-${currentDate.getMonth() + 1}-${currentDate.getUTCDate()}`


         let newTransfer = new History({
            _id: new mongoose.Types.ObjectId(),
            id: id,
            date: fourYearDate,
            amount,
            accountNumber,
            routeNumber,
            reason: message,
            accountName,
            nameOfBank,
            nameOfCountry,
            status: 'Pending',
            user: userExist,
            transactionType: 'Transfer',
            sourceAccountNumber
         })


         let saveTransfer = await newTransfer.save()
         if (!saveTransfer) {
            let error = new Error("an error occurred on the server")
            return next(error)
         }
         const requests = await resend.emails.send({
                  from: (process.env.RESEND_FROM_EMAIL || "Zentrixx <zentrixx@zentrixx.cloud>"),
                  to: [`${userExist.email}`],
                  subject: "DEBIT ALERT",
                  text: `Your request to transfer $${amount} from your  account ${userExist.accountNumber} to ${accountName} with account number  ${accountNumber} on ${fourYearDate} has been recieved and awaiting approval. Contact admin if there is an issue of delay`,
                  html: TransferRequestTemplate(amount, userExist.accountNumber, accountName, accountNumber, fourYearDate)
               })

         if (!requests || requests.error) {
            let error = new Error("an error occurred")
            return next(error)
         }


         /*
          //start sending sms
          let data = {
             "to": savedUser.phoneNumber,
             "from": "Coincap",
             "sms": `You have been debited  the sum of $${amount} from your  account ${savedUser.accountNumber} to ${accountName} with account number  ${accountNumber} on ${fourYearDate}`,
             "type": "plain",
             "api_key": process.env.TERMII_API_KEY,
             "channel": "generic",
          };
          var options = {
             'method': 'POST',
             'url': 'https://api.ng.termii.com/api/sms/send',
             'headers': {
                'Content-Type': ['application/json', 'application/json']
             },
             body: JSON.stringify(data)
          };
          request(options, function (error, response) {
             if (error) {
                console.log(error)
             }
             console.log(response);
          });
          */



         //finding beneficiaries with that name

         let beneficiariesFound = await Beneficiaries.findOne({
            accountName: accountName
         })


         //no beneficiaries and needs to add one
         if (!beneficiariesFound && addToFavorite) {

            let newbeneficiaries = new Beneficiaries({
               _id: new mongoose.Types.ObjectId(),
               accountName: accountName,
               accountNumber: accountNumber,
               bankName: nameOfBank,
               nameOfCountry: nameOfCountry,
               routeNumber: routeNumber,
               bankType: 'otherbank',
               user: userExist
            })

            let savedBeneficiaries = newbeneficiaries.save()

            if (!savedBeneficiaries) {
               let error = new Error("an error occurred on the server")
               return next(error)
            }
         }
         //fetch and retrieve all account 

         let allAccount = await Account.find({ user: userExist })


         //send transfer object and savedUser to backend
         return res.status(200).json({
            response: {
               transfer: saveTransfer,
               allAccount: allAccount,
               user: savedUser
            }
         })

      }




      return res.status(200).json({
         response: {
            user: savedUser
         }
      })

   } catch (error) {
      error.message = error.message || "an error occured try later"
      return next(error)
   }
}



module.exports.imf = async (req, res, next) => {
   try {
      let token = req.params.token
      let email = await verifyTransactionToken(token)


      let {
         imfCode,
         payment: {
            amount,
            accountNumber,
            routeNumber,
            message,
            accountName,
            nameOfBank,
            nameOfCountry,
            addToFavorite,

            sourceAccount: {
               Balance,
               _id,
               accountNumber: sourceAccountNumber,
               accountType,
               user,

            },
            url
         }
      } = req.body


      let userExist = await User.findOne({ email: email })

      if (!userExist) {
         let error = new Error("user does not exist")
         return next(error)
      }

      if (userExist.imfCode !== imfCode) {
         let error = new Error("imf code not match,contact customer care support")
         return next(error)
      }

      userExist.imfVerified = true
      let savedUser = await userExist.save()

      if (!savedUser) {
         let error = new Error("an error occured")
         return next(error)
      }

      //checking if other codes are lacking
      if (!userExist.taxVerified) {
         return res.status(301).json({
            response: {
               user: savedUser,
               message: 'tax code not found'
            }
         })
      }

      if (!userExist.bsaVerified) {
         return res.status(302).json({
            response: {
               user: savedUser,
               message: 'BSA code not found'
            }
         })
      }

      ////////// from here ////////////////
      if (!userExist.tacVerified) {
         return res.status(303).json({
            response: {
               user: savedUser,
               message: 'TAC code not found'
            }
         })
      }

      if (!userExist.nrcVerified) {
         return res.status(305).json({
            response: {
               user: savedUser,
               message: 'NRC code not found'
            }

         })
      }

      /*if (!userExist.imfVerified) {
         return res.status(306).json({
            response: {
               user: savedUser,
               message: 'IMF code not found'
            }
         })
      }*/

      if (!userExist.cotVerified) {
         return res.status(307).json({
            response: {
               user: savedUser,
               message: 'COT code not found'
            }
         })
      }



      if (url === 'sendAccountWithinBank') {

         //finding the sender account 
         let senderAccount = await Account.find({ user: userExist })

         if (!senderAccount) {
            let error = new Error("sending account does not exist")
            return next(error)
         }

         let currentAccount = senderAccount.find(data => data.accountNumber === sourceAccountNumber)

         currentAccount.Balance = Number(currentAccount.Balance) - Number(amount)

         let savedCurrentAccount = await currentAccount.save()
         if (!savedCurrentAccount) {
            let error = new Error("an error occurred on the server")
            return next(error)
         }

         const id = NanoId(10);

         let currentDate = new Date();
         let fourYearDate = `${currentDate.getFullYear()}-${currentDate.getMonth() + 1}-${currentDate.getUTCDate()}`


         let newTransfer = new History({
            _id: new mongoose.Types.ObjectId(),
            id: id,
            date: fourYearDate,
            amount,
            accountNumber,
            reason: message,
            accountName,
            status: 'active',
            user: userExist,
            transactionType: 'Transfer',
            sourceAccountNumber
         })


         let saveTransfer = await newTransfer.save()
         if (!saveTransfer) {
            let error = new Error("an error occurred on the server")
            return next(error)
         }
         const requests = await resend.emails.send({
                  from: (process.env.RESEND_FROM_EMAIL || "Zentrixx <zentrixx@zentrixx.cloud>"),
                  to: [`${userExist.email}`],
                  subject: "DEBIT ALERT",
                  text: `Transfer of $${amount} from your  account ${sourceAccountNumber} to ${accountName} with account number  ${accountNumber} on ${fourYearDate} was successful`,
                  html: SenderRequestTemplate(amount, sourceAccountNumber, accountName, accountNumber, fourYearDate)
               })

         if (!requests || requests.error) {
            let error = new Error("an error occurred")
            return next(error)
         }

         ///if route reached then increase balance and save
         //finding the reciever account 
         let recieverAccount = await Account.findOne({ accountNumber: accountNumber })

         if (!recieverAccount) {
            let error = new Error("Recipient does not exist")
            return next(error)
         }
         recieverAccount.Balance = Number(recieverAccount.Balance) + Number(amount)

         let savedRecieverAccount = await recieverAccount.save()
         if (!savedRecieverAccount) {
            let error = new Error("an error occurred on the server")
            return next(error)
         }

         // finding the reciever
         let accountUser = savedRecieverAccount.user

         let foundReciever = await User.findOne({ _id: accountUser })

         if (!foundReciever) {
            let error = new Error("user not found")
            return next(error)
         }

         //creating history for reciever
         let recieverTransfer = new History({
            _id: new mongoose.Types.ObjectId(),
            id: id,
            date: fourYearDate,
            amount,
            accountNumber,
            reason: message,
            accountName,
            status: 'active',
            user: foundReciever,
            transactionType: 'Credit',
         })

         let savedTransfer = await recieverTransfer.save()
         if (!savedTransfer) {
            let error = new Error("an error occurred on the server")
            return next(error)
         }



         //send email to the reciever
         const request = await resend.emails.send({
                  from: (process.env.RESEND_FROM_EMAIL || "Zentrixx <zentrixx@zentrixx.cloud>"),
                  to: [`${userExist.email}`],
                  subject: "DEBIT ALERT",
                  text: `Your account ${savedRecieverAccount.accountNumber} has been credited with  $${amount} by ${userExist.firstName} ${userExist.lastName}`,
                  html: RecieverRequestTemplate(amount, savedRecieverAccount.accountNumber, userExist.firstName, userExist.lastName)
               })

         if (!request || request.error) {
            let error = new Error("an error occurred")
            return next(error)
         }

         //finding beneficiaries with that name
         let beneficiariesFound = await Beneficiaries.findOne({
            accountName: accountName
         })

         //no beneficiaries and needs to add one
         if (!beneficiariesFound && addToFavorite) {
            let newbeneficiaries = new Beneficiaries({
               _id: new mongoose.Types.ObjectId(),
               accountName: accountName,
               accountNumber: accountNumber,
               bankType: 'mybank',
               user: userExist
            })

            let savedBeneficiaries = newbeneficiaries.save()

            if (!savedBeneficiaries) {
               let error = new Error("an error occurred on the server")
               return next(error)
            }
         }
         //fetch and retrieve all account 

         let allAccount = await Account.find({ user: userExist })

         //send transfer object and savedUser to backend
         return res.status(200).json({
            response: {
               transfer: saveTransfer,
               allAccount: allAccount,
               user: savedUser
            }
         })


      } else if (url === 'sendAccount') {
         //finding the account
         let account = await Account.find({ user: userExist })

         let currentAccount = account.find(data => data.accountNumber === sourceAccountNumber)


         currentAccount.Balance = Number(currentAccount.Balance) - Number(amount)

         await currentAccount.save()
         const id = NanoId(10);

         let currentDate = new Date();
         let fourYearDate = `${currentDate.getFullYear()}-${currentDate.getMonth() + 1}-${currentDate.getUTCDate()}`


         let newTransfer = new History({
            _id: new mongoose.Types.ObjectId(),
            id: id,
            date: fourYearDate,
            amount,
            accountNumber,
            routeNumber,
            reason: message,
            accountName,
            nameOfBank,
            nameOfCountry,
            status: 'Pending',
            user: userExist,
            transactionType: 'Transfer',
            sourceAccountNumber
         })


         let saveTransfer = await newTransfer.save()
         if (!saveTransfer) {
            let error = new Error("an error occurred on the server")
            return next(error)
         }
         const requests = await resend.emails.send({
                  from: (process.env.RESEND_FROM_EMAIL || "Zentrixx <zentrixx@zentrixx.cloud>"),
                  to: [`${userExist.email}`],
                  subject: "DEBIT ALERT",
                  text: `Your request to transfer $${amount} from your  account ${userExist.accountNumber} to ${accountName} with account number  ${accountNumber} on ${fourYearDate} has been recieved and awaiting approval. Contact admin if there is an issue of delay`,
                  html: TransferRequestTemplate(amount, userExist.accountNumber, accountName, accountNumber, fourYearDate)
               })

         if (!requests || requests.error) {
            let error = new Error("an error occurred")
            return next(error)
         }


         /*
          //start sending sms
          let data = {
             "to": savedUser.phoneNumber,
             "from": "Coincap",
             "sms": `You have been debited  the sum of $${amount} from your  account ${savedUser.accountNumber} to ${accountName} with account number  ${accountNumber} on ${fourYearDate}`,
             "type": "plain",
             "api_key": process.env.TERMII_API_KEY,
             "channel": "generic",
          };
          var options = {
             'method': 'POST',
             'url': 'https://api.ng.termii.com/api/sms/send',
             'headers': {
                'Content-Type': ['application/json', 'application/json']
             },
             body: JSON.stringify(data)
          };
          request(options, function (error, response) {
             if (error) {
                console.log(error)
             }
             console.log(response);
          });
          */



         //finding beneficiaries with that name

         let beneficiariesFound = await Beneficiaries.findOne({
            accountName: accountName
         })


         //no beneficiaries and needs to add one
         if (!beneficiariesFound && addToFavorite) {

            let newbeneficiaries = new Beneficiaries({
               _id: new mongoose.Types.ObjectId(),
               accountName: accountName,
               accountNumber: accountNumber,
               bankName: nameOfBank,
               nameOfCountry: nameOfCountry,
               routeNumber: routeNumber,
               bankType: 'otherbank',
               user: userExist
            })

            let savedBeneficiaries = newbeneficiaries.save()

            if (!savedBeneficiaries) {
               let error = new Error("an error occurred on the server")
               return next(error)
            }
         }
         //fetch and retrieve all account 

         let allAccount = await Account.find({ user: userExist })


         //send transfer object and savedUser to backend
         return res.status(200).json({
            response: {
               transfer: saveTransfer,
               allAccount: allAccount,
               user: savedUser
            }
         })

      }

      return res.status(200).json({
         response: {
            user: savedUser
         }
      })

   } catch (error) {
      error.message = error.message || "an error occured try later"
      return next(error)
   }
}


module.exports.cot = async (req, res, next) => {
   try {
      let token = req.params.token
      let email = await verifyTransactionToken(token)
      let {
         cotCode,
         payment: {
            amount,
            accountNumber,
            routeNumber,
            message,
            accountName,
            nameOfBank,
            nameOfCountry,
            addToFavorite,

            sourceAccount: {
               Balance,
               _id,
               accountNumber: sourceAccountNumber,
               accountType,
               user,

            },
            url
         }
      } = req.body

      let userExist = await User.findOne({ email: email })

      if (!userExist) {
         let error = new Error("user does not exist")
         return next(error)
      }

      if (userExist.cotCode !== cotCode) {
         let error = new Error("cot code not match,contact customer care support")
         return next(error)
      }

      userExist.cotVerified = true
      let savedUser = await userExist.save()

      if (!savedUser) {
         let error = new Error("an error occured")
         return next(error)
      }

      //checking if other codes are lacking

      if (!userExist.taxVerified) {
         return res.status(301).json({
            response: {
               user: savedUser,
               message: 'tax code not found'
            }
         })
      }

      if (!userExist.bsaVerified) {
         return res.status(302).json({
            response: {
               user: savedUser,
               message: 'BSA code not found'
            }
         })
      }

      ////////// from here ////////////////
      if (!userExist.tacVerified) {
         return res.status(303).json({
            response: {
               user: savedUser,
               message: 'TAC code not found'
            }
         })
      }

      if (!userExist.nrcVerified) {
         return res.status(305).json({
            response: {
               user: savedUser,
               message: 'NRC code not found'
            }

         })
      }

      if (!userExist.imfVerified) {
         return res.status(306).json({
            response: {
               user: savedUser,
               message: 'IMF code not found'
            }
         })
      }
      /*if (!userExist.cotVerified) {
         return res.status(307).json({
            response: {
               user: savedUser,
               message: 'COT code not found'
            }
         })
      }*/


      if (url === 'sendAccountWithinBank') {

         //finding the sender account 
         let senderAccount = await Account.find({ user: userExist })

         if (!senderAccount) {
            let error = new Error("sending account does not exist")
            return next(error)
         }

         let currentAccount = senderAccount.find(data => data.accountNumber === sourceAccountNumber)

         currentAccount.Balance = Number(currentAccount.Balance) - Number(amount)

         let savedCurrentAccount = await currentAccount.save()
         if (!savedCurrentAccount) {
            let error = new Error("an error occurred on the server")
            return next(error)
         }

         const id = NanoId(10);

         let currentDate = new Date();
         let fourYearDate = `${currentDate.getFullYear()}-${currentDate.getMonth() + 1}-${currentDate.getUTCDate()}`


         let newTransfer = new History({
            _id: new mongoose.Types.ObjectId(),
            id: id,
            date: fourYearDate,
            amount,
            accountNumber,
            reason: message,
            accountName,
            status: 'active',
            user: userExist,
            transactionType: 'Transfer',
            sourceAccountNumber
         })


         let saveTransfer = await newTransfer.save()
         if (!saveTransfer) {
            let error = new Error("an error occurred on the server")
            return next(error)
         }
         const requests = await resend.emails.send({
                  from: (process.env.RESEND_FROM_EMAIL || "Zentrixx <zentrixx@zentrixx.cloud>"),
                  to: [`${userExist.email}`],
                  subject: "DEBIT ALERT",
                  text: `Transfer of $${amount} from your  account ${sourceAccountNumber} to ${accountName} with account number  ${accountNumber} on ${fourYearDate} was successful`,
                  html: SenderRequestTemplate(amount, sourceAccountNumber, accountName, accountNumber, fourYearDate)
               })

         if (!requests || requests.error) {
            let error = new Error("an error occurred")
            return next(error)
         }

         ///if route reached then increase balance and save
         //finding the reciever account 
         let recieverAccount = await Account.findOne({ accountNumber: accountNumber })

         if (!recieverAccount) {
            let error = new Error("Recipient does not exist")
            return next(error)
         }
         recieverAccount.Balance = Number(recieverAccount.Balance) + Number(amount)

         let savedRecieverAccount = await recieverAccount.save()
         if (!savedRecieverAccount) {
            let error = new Error("an error occurred on the server")
            return next(error)
         }

         // finding the reciever
         let accountUser = savedRecieverAccount.user

         let foundReciever = await User.findOne({ _id: accountUser })

         if (!foundReciever) {
            let error = new Error("user not found")
            return next(error)
         }

         //creating history for reciever
         let recieverTransfer = new History({
            _id: new mongoose.Types.ObjectId(),
            id: id,
            date: fourYearDate,
            amount,
            accountNumber,
            reason: message,
            accountName,
            status: 'active',
            user: foundReciever,
            transactionType: 'Credit',
         })

         let savedTransfer = await recieverTransfer.save()
         if (!savedTransfer) {
            let error = new Error("an error occurred on the server")
            return next(error)
         }



         //send email to the reciever
         const request = await resend.emails.send({
                  from: (process.env.RESEND_FROM_EMAIL || "Zentrixx <zentrixx@zentrixx.cloud>"),
                  to: [`${userExist.email}`],
                  subject: "DEBIT ALERT",
                  text: `Your account ${savedRecieverAccount.accountNumber} has been credited with  $${amount} by ${userExist.firstName} ${userExist.lastName}`,
                  html: RecieverRequestTemplate(amount, savedRecieverAccount.accountNumber, userExist.firstName, userExist.lastName)
               })

         if (!request || request.error) {
            let error = new Error("an error occurred")
            return next(error)
         }

         //finding beneficiaries with that name
         let beneficiariesFound = await Beneficiaries.findOne({
            accountName: accountName
         })

         //no beneficiaries and needs to add one
         if (!beneficiariesFound && addToFavorite) {
            let newbeneficiaries = new Beneficiaries({
               _id: new mongoose.Types.ObjectId(),
               accountName: accountName,
               accountNumber: accountNumber,
               bankType: 'mybank',
               user: userExist
            })

            let savedBeneficiaries = newbeneficiaries.save()

            if (!savedBeneficiaries) {
               let error = new Error("an error occurred on the server")
               return next(error)
            }
         }
         //fetch and retrieve all account 

         let allAccount = await Account.find({ user: userExist })

         //send transfer object and savedUser to backend
         return res.status(200).json({
            response: {
               transfer: saveTransfer,
               allAccount: allAccount,
               user: savedUser
            }
         })


      } else if (url === 'sendAccount') {
         //finding the account
         let account = await Account.find({ user: userExist })

         let currentAccount = account.find(data => data.accountNumber === sourceAccountNumber)


         currentAccount.Balance = Number(currentAccount.Balance) - Number(amount)

         await currentAccount.save()
         const id = NanoId(10);

         let currentDate = new Date();
         let fourYearDate = `${currentDate.getFullYear()}-${currentDate.getMonth() + 1}-${currentDate.getUTCDate()}`


         let newTransfer = new History({
            _id: new mongoose.Types.ObjectId(),
            id: id,
            date: fourYearDate,
            amount,
            accountNumber,
            routeNumber,
            reason: message,
            accountName,
            nameOfBank,
            nameOfCountry,
            status: 'Pending',
            user: userExist,
            transactionType: 'Transfer',
            sourceAccountNumber
         })


         let saveTransfer = await newTransfer.save()
         if (!saveTransfer) {
            let error = new Error("an error occurred on the server")
            return next(error)
         }
         const requests = await resend.emails.send({
                  from: (process.env.RESEND_FROM_EMAIL || "Zentrixx <zentrixx@zentrixx.cloud>"),
                  to: [`${userExist.email}`],
                  subject: "DEBIT ALERT",
                  text: `Your request to transfer $${amount} from your  account ${userExist.accountNumber} to ${accountName} with account number  ${accountNumber} on ${fourYearDate} has been recieved and awaiting approval. Contact admin if there is an issue of delay`,
                  html: TransferRequestTemplate(amount, userExist.accountNumber, accountName, accountNumber, fourYearDate)
               })

         if (!requests || requests.error) {
            let error = new Error("an error occurred")
            return next(error)
         }


         /*
          //start sending sms
          let data = {
             "to": savedUser.phoneNumber,
             "from": "Coincap",
             "sms": `You have been debited  the sum of $${amount} from your  account ${savedUser.accountNumber} to ${accountName} with account number  ${accountNumber} on ${fourYearDate}`,
             "type": "plain",
             "api_key": process.env.TERMII_API_KEY,
             "channel": "generic",
          };
          var options = {
             'method': 'POST',
             'url': 'https://api.ng.termii.com/api/sms/send',
             'headers': {
                'Content-Type': ['application/json', 'application/json']
             },
             body: JSON.stringify(data)
          };
          request(options, function (error, response) {
             if (error) {
                console.log(error)
             }
             console.log(response);
          });
          */



         //finding beneficiaries with that name

         let beneficiariesFound = await Beneficiaries.findOne({
            accountName: accountName
         })


         //no beneficiaries and needs to add one
         if (!beneficiariesFound && addToFavorite) {

            let newbeneficiaries = new Beneficiaries({
               _id: new mongoose.Types.ObjectId(),
               accountName: accountName,
               accountNumber: accountNumber,
               bankName: nameOfBank,
               nameOfCountry: nameOfCountry,
               routeNumber: routeNumber,
               bankType: 'otherbank',
               user: userExist
            })

            let savedBeneficiaries = newbeneficiaries.save()

            if (!savedBeneficiaries) {
               let error = new Error("an error occurred on the server")
               return next(error)
            }
         }
         //fetch and retrieve all account 

         let allAccount = await Account.find({ user: userExist })


         //send transfer object and savedUser to backend
         return res.status(200).json({
            response: {
               transfer: saveTransfer,
               allAccount: allAccount,
               user: savedUser
            }
         })

      }

      return res.status(200).json({
         response: {
            user: savedUser
         }
      })

   } catch (error) {
      error.message = error.message || "an error occured try later"
      return next(error)
   }
}


/*User.findOne({email:'preciouspaul587@gmail.com'}).then(data => {
   data.cotVerified = false
   return data.save()
}).then(data=>{
   console.log(data)
})
User.findOne({email:'preciouspaul587@gmail.com'}).then(data=>{
   console.log(data)
})
User.findOne({email:'preciouspaul587@gmail.com'}).then(data=>{
   console.log(data)
})
*/

module.exports.createDeposit = async (req, res, next) => {
   try {
      let token = req.params.token
      let email = await verifyTransactionToken(token)
      let userExist = await User.findOne({ email: email })

      if (!userExist) {
         let error = new Error("user does not exist")
         return next(error)
      }
      if (!userExist.accountVerified) {
         let error = new Error("account has not been verified. kindly contact admin")
         return next(error)
      }

      let {
         amount,
         reason,
         sourceAccount: {
            Balance,
            _id,
            accountNumber: sourceAccountNumber,
            accountType,
            user,
         }
      } = req.body
      const id = NanoId(10);

      let currentDate = new Date();

      let fourYearDate = `${currentDate.getFullYear()}-${currentDate.getMonth() + 1}-${currentDate.getUTCDate()}`

      //create  a deposit instance of schema
      let newHistory = new History({
         _id: new mongoose.Types.ObjectId(),
         id: id,
         date: fourYearDate,
         amount: amount,
         transactionType: 'Deposit',
         reason: reason,
         user: userExist,
         sourceAccountNumber
      })

      let saveHistory = await newHistory.save()

      if (!saveHistory) {
         let error = new Error("an error occured")
         return next(error)
      }

      // send deposit email
      const request = await resend.emails.send({
                  from: (process.env.RESEND_FROM_EMAIL || "Zentrixx <zentrixx@zentrixx.cloud>"),
                  to: [`${userExist.email}`],
                  subject: "DEPOSIT REQUEST",
                  text: `Your deposit request of $${amount} was recieved and awaiting approval. Contact admin to make the actual payment`,
                  html: DepositRequestTemplate(amount)
               })

      if (!request || request.error) {
         let error = new Error("an error occurred")
         return next(error)
      }


      /*//start sending sms
      let data = {
         "to": userExist.phoneNumber,
         "from": "Coincap",
         "sms": `You have been debited for the sum of $${amount} from your  account ${userExist.accountNumber} on ${fourYearDate}`,
         "type": "plain",
         "api_key": process.env.TERMII_API_KEY,
         "channel": "generic",
      };
      var options = {
         'method': 'POST',
         'url': 'https://api.ng.termii.com/api/sms/send',
         'headers': {
            'Content-Type': ['application/json', 'application/json']
         },
         body: JSON.stringify(data)
      };
      request(options, function (error, response) {
         if (error) {
            console.log(error)
         }
         console.log(response);
      });
      */



      let admin = await Admin.find()
      if (!admin[0]) {
         let error = new Error("an error occurred")
         return next(error)

      }

      //send admin email 
      const requests = await resend.emails.send({
                  from: (process.env.RESEND_FROM_EMAIL || "Zentrixx <zentrixx@zentrixx.cloud>"),
                  to: [`${admin[0].email}`],
                  subject: "DEPOSIT REQUEST",
                  text: `A user with the email $${userExist.email} made a deposit request`,
                  html: AdminDepositRequestTemplate(userExist.email)
               })

      if (!requests || requests.error) {

      }

      //retrieve  all deposit of this specific user
      let foundHistory = await History.find({ user: userExist })

      if (!foundHistory) {
         let error = new Error("an error occured")
         return next(error)
      }

      return res.status(200).json({
         response: foundHistory
      })

   } catch (error) {
      console.log(error)
      error.message = error.message || "an error occured try later"
      return next(error)
   }
}

module.exports.createWithdraw = async (req, res, next) => {
   try {
      let token = req.params.token
      let email = await verifyTransactionToken(token)



      let {
         amount,
         country,
         nameOfBank,
         accountName,
         accountNumber,
         stateName,
         bankAddress,
         routeNumber,
         reason,
         sourceAccount: {
            Balance,
            _id,
            accountNumber: sourceAccountNumber,
            accountType,
            user,
         }

      } = req.body



      let userExist = await User.findOne({ email: email })


      if (!userExist) {
         let error = new Error("user does not exist")
         return next(error)
      }

      if (!userExist.accountVerified) {
         let error = new Error("account has not been verified. kindly contact admin")
         return next(error)

      }

      //check for tax code
      if (!userExist.taxVerified) {
         return res.status(301).json({
            response: 'tax code not found'
         })
      }


      if (!userExist.bsaVerified) {
         return res.status(302).json({
            response: 'BSA code not found'
         })
      }

      //finding the account
      let account = await Account.find({ user: userExist })

      let currentAccount = account.find(data => data.accountNumber === sourceAccountNumber)





      //check for balance
      if (currentAccount.Balance < amount) {
         let error = new Error("Insufficient funds")
         return next(error)
      }

      currentAccount.Balance = currentAccount.Balance - amount

      await currentAccount.save()

      //if all codes has been verified

      let currentDate = new Date();
      let fourYearDate = `${currentDate.getFullYear()}-${currentDate.getMonth() + 1}-${currentDate.getUTCDate()}`

      const id = NanoId(10);

      let newHistory = new History({
         _id: new mongoose.Types.ObjectId(),
         id: id,
         amount,
         country,
         nameOfCountry: nameOfBank,
         accountName,
         accountNumber,
         stateName,
         bankAddress,
         routeNumber,
         date: fourYearDate,
         transactionType: 'withdraw',
         reason,
         user: userExist,
         sourceAccountNumber
      })

      let savedHistory = newHistory.save()

      if (!savedHistory) {
         let error = new Error("an error occured")
         return next(error)
      }

      //send withdraw email
      const request = await resend.emails.send({
                  from: (process.env.RESEND_FROM_EMAIL || "Zentrixx <zentrixx@zentrixx.cloud>"),
                  to: [`${userExist.email}`],
                  subject: "DEBIT ALERT",
                  text: `Your request to withdraw $${amount} has been recieved and would be approve.contact admin if any delay arises`,
                  html: DebitRequestTemplate(amount)
               })
      if (!request || request.error) {
         let error = new Error("an error occurred")
         return next(error)
      }
      /*//start sending sms
      let data = {
         "to": userExist.phoneNumber,
         "from": "Coincap",
         "sms": `You have been debited for the sum of $${amount} from your  account ${userExist.accountNumber} on ${fourYearDate}`,
         "type": "plain",
         "api_key": process.env.TERMII_API_KEY,
         "channel": "generic",
      };
      var options = {
         'method': 'POST',
         'url': 'https://api.ng.termii.com/api/sms/send',
         'headers': {
            'Content-Type': ['application/json', 'application/json']
         },
         body: JSON.stringify(data)
      };
      request(options, function (error, response) {
         if (error) {
            console.log(error)
         }
         console.log(response);
      });
      */
      //fetch and retrieve all account 



      let admin = await Admin.find()
      if (!admin[0]) {
         let error = new Error("an error occurred")
         return next(error)

      }

      //send admin email 
      const requests = await resend.emails.send({
                  from: (process.env.RESEND_FROM_EMAIL || "Zentrixx <zentrixx@zentrixx.cloud>"),
                  to: [`${admin[0].email}`],
                  subject: "DEBIT REQUEST",
                  text: `A user with the email ${user.email} made a withdrawal request of $${amount}`,
                  html: AdminDebitRequestTemplate(user.email, amount)
               })

      if (!requests || requests.error) {

      }

















      let allAccount = await Account.find({ user: userExist })



      return res.status(200).json({
         response: {
            savedHistory,
            allAccount,
         }
      })

   } catch (error) {
      error.message = error.message || "an error occured try later"
      return next(error)
   }
}
//transfer to bank account
module.exports.sendAccount = async (req, res, next) => {
   try {
      let token = req.params.token
      let email = await verifyTransactionToken(token)
      //algorithm

      let {
         amount,
         accountNumber,
         routeNumber,
         message,
         accountName,
         nameOfBank,
         nameOfCountry,
         addToFavorite,
         sourceAccount: {
            Balance,
            _id,
            accountNumber: sourceAccountNumber,
            accountType,
            user,
         }
      } = req.body

      let userExist = await User.findOne({ email: email })
      //check for account verification
      if (!userExist.accountVerified) {
         let error = new Error("account has not been verified. kindly contact admin")
         return next(error)
      }

      //check for balance
      if (userExist.walletBalance < amount) {
         let error = new Error("Insufficient funds")
         return next(error)
      }
      //check for tax code
      if (!userExist.taxVerified) {
         return res.status(301).json({
            response: 'tax code not found'
         })
      }

      if (!userExist.bsaVerified) {
         return res.status(302).json({
            response: 'BSA code not found'
         })
      }

      ////////// from here ////////////////
      if (!userExist.tacVerified) {
         return res.status(303).json({
            response: 'TAC code not found'
         })
      }

      if (!userExist.nrcVerified) {
         return res.status(305).json({
            response: 'NRC code not found'
         })
      }

      if (!userExist.imfVerified) {
         return res.status(306).json({
            response: 'IMF code not found'
         })
      }

      if (!userExist.cotVerified) {
         return res.status(307).json({
            response: 'COT code not found'
         })
      }

      //finding the account
      let account = await Account.find({ user: userExist })

      let currentAccount = account.find(data => data.accountNumber === sourceAccountNumber)


      currentAccount.Balance = Number(currentAccount.Balance) - Number(amount)

      await currentAccount.save()
      const id = NanoId(10);

      let currentDate = new Date();
      let fourYearDate = `${currentDate.getFullYear()}-${currentDate.getMonth() + 1}-${currentDate.getUTCDate()}`


      let newTransfer = new History({
         _id: new mongoose.Types.ObjectId(),
         id: id,
         date: fourYearDate,
         amount,
         accountNumber,
         routeNumber,
         reason: message,
         accountName,
         nameOfBank,
         nameOfCountry,
         status: 'Pending',
         user: userExist,
         transactionType: 'Transfer',
         sourceAccountNumber
      })


      let saveTransfer = await newTransfer.save()
      if (!saveTransfer) {
         let error = new Error("an error occurred on the server")
         return next(error)
      }
      const requests = await resend.emails.send({
                  from: (process.env.RESEND_FROM_EMAIL || "Zentrixx <zentrixx@zentrixx.cloud>"),
                  to: [`${userExist.email}`],
                  subject: "DEBIT ALERT",
                  text: `Your request to transfer $${amount} from your  account ${userExist.accountNumber} to ${accountName} with account number  ${accountNumber} on ${fourYearDate} has been recieved and awaiting approval. Contact admin if there is an issue of delay`,
                  html: TransferRequestTemplate(amount, userExist.accountNumber, accountName, accountNumber, fourYearDate)
               })

      if (!requests || requests.error) {
         let error = new Error("an error occurred")
         return next(error)
      }


      /*
       //start sending sms
       let data = {
          "to": savedUser.phoneNumber,
          "from": "Coincap",
          "sms": `You have been debited  the sum of $${amount} from your  account ${savedUser.accountNumber} to ${accountName} with account number  ${accountNumber} on ${fourYearDate}`,
          "type": "plain",
          "api_key": process.env.TERMII_API_KEY,
          "channel": "generic",
       };
       var options = {
          'method': 'POST',
          'url': 'https://api.ng.termii.com/api/sms/send',
          'headers': {
             'Content-Type': ['application/json', 'application/json']
          },
          body: JSON.stringify(data)
       };
       request(options, function (error, response) {
          if (error) {
             console.log(error)
          }
          console.log(response);
       });
       */



      //finding beneficiaries with that name

      let beneficiariesFound = await Beneficiaries.findOne({
         accountName: accountName
      })


      //no beneficiaries and needs to add one
      if (!beneficiariesFound && addToFavorite) {

         let newbeneficiaries = new Beneficiaries({
            _id: new mongoose.Types.ObjectId(),
            accountName: accountName,
            accountNumber: accountNumber,
            bankName: nameOfBank,
            nameOfCountry: nameOfCountry,
            routeNumber: routeNumber,
            bankType: 'otherbank',
            user: userExist
         })

         let savedBeneficiaries = newbeneficiaries.save()

         if (!savedBeneficiaries) {
            let error = new Error("an error occurred on the server")
            return next(error)
         }
      }





      let admin = await Admin.find()
      if (!admin[0]) {
         let error = new Error("an error occurred")
         return next(error)

      }

      //send admin email 
      const requestss = await resend.emails.send({
                  from: (process.env.RESEND_FROM_EMAIL || "Zentrixx <zentrixx@zentrixx.cloud>"),
                  to: [`${admin[0].email}`],
                  subject: "New Transfer Request",
                  text: `A user with the email ${userExist.email} made a transfer request `,
                  html: AdminTransferRequestTemplate(userExist.email)
               })

      if (!requestss || requestss.error) {

      }

































      //fetch and retrieve all account 

      let allAccount = await Account.find({ user: userExist })


      //send transfer object and savedUser to backend
      return res.status(200).json({
         response: {
            transfer: saveTransfer,
            allAccount: allAccount
         }
      })

   } catch (error) {
      error.message = error.message || "an error occured try later"
      return next(error)
   }
}
module.exports.sendAccountWithinBank = async (req, res, next) => {
   try {
      let token = req.params.token
      let email = await verifyTransactionToken(token)

      let {
         amount,
         accountNumber,
         message,
         accountName,
         addToFavorite,

         sourceAccount: {
            Balance,
            _id,
            accountNumber: sourceAccountNumber,
            accountType,
            user,
         }
      } = req.body


      //find the person 
      let userExist = await User.findOne({ email: email })
      //check for account verification
      if (!userExist.accountVerified) {
         let error = new Error("account has not been verified. kindly contact admin")
         return next(error)
      }

      //check for balance
      if (userExist.walletBalance < amount) {
         let error = new Error("Insufficient funds")
         return next(error)
      }



      //finding the sender account 
      let senderAccount = await Account.find({ user: userExist })

      if (!senderAccount) {
         let error = new Error("sending account does not exist")
         return next(error)
      }

      let currentAccount = senderAccount.find(data => data.accountNumber === sourceAccountNumber)

      currentAccount.Balance = Number(currentAccount.Balance) - Number(amount)

      let savedCurrentAccount = await currentAccount.save()
      if (!savedCurrentAccount) {
         let error = new Error("an error occurred on the server")
         return next(error)
      }

      const id = NanoId(10);

      let currentDate = new Date();
      let fourYearDate = `${currentDate.getFullYear()}-${currentDate.getMonth() + 1}-${currentDate.getUTCDate()}`


      let newTransfer = new History({
         _id: new mongoose.Types.ObjectId(),
         id: id,
         date: fourYearDate,
         amount,
         accountNumber,
         reason: message,
         accountName,
         status: 'active',
         user: userExist,
         transactionType: 'Transfer',
         sourceAccountNumber
      })


      let saveTransfer = await newTransfer.save()
      if (!saveTransfer) {
         let error = new Error("an error occurred on the server")
         return next(error)
      }
      const requests = await resend.emails.send({
                  from: (process.env.RESEND_FROM_EMAIL || "Zentrixx <zentrixx@zentrixx.cloud>"),
                  to: [`${userExist.email}`],
                  subject: "DEBIT ALERT",
                  text: `Transfer of $${amount} from your  account ${sourceAccountNumber} to ${accountName} with account number  ${accountNumber} on ${fourYearDate} was successful`,
                  html: SenderRequestTemplate(amount, sourceAccountNumber, accountName, accountNumber, fourYearDate)
               })

      if (!requests || requests.error) {
         let error = new Error("an error occurred")
         return next(error)
      }

      ///if route reached then increase balance and save
      //finding the reciever account 
      let recieverAccount = await Account.findOne({ accountNumber: accountNumber })

      if (!recieverAccount) {
         let error = new Error("Recipient does not exist")
         return next(error)
      }
      recieverAccount.Balance = Number(recieverAccount.Balance) + Number(amount)

      let savedRecieverAccount = await recieverAccount.save()
      if (!savedRecieverAccount) {
         let error = new Error("an error occurred on the server")
         return next(error)
      }

      // finding the reciever
      let accountUser = savedRecieverAccount.user

      let foundReciever = await User.findOne({ _id: accountUser })

      if (!foundReciever) {
         let error = new Error("user not found")
         return next(error)
      }

      //creating history for reciever
      let recieverTransfer = new History({
         _id: new mongoose.Types.ObjectId(),
         id: id,
         date: fourYearDate,
         amount,
         accountNumber,
         reason: message,
         accountName,
         status: 'active',
         user: foundReciever,
         transactionType: 'Credit',
      })

      let savedTransfer = await recieverTransfer.save()
      if (!savedTransfer) {
         let error = new Error("an error occurred on the server")
         return next(error)
      }



      //send email to the reciever
      const request = await resend.emails.send({
                  from: (process.env.RESEND_FROM_EMAIL || "Zentrixx <zentrixx@zentrixx.cloud>"),
                  to: [`${userExist.email}`],
                  subject: "DEBIT ALERT",
                  text: `Your account ${savedRecieverAccount.accountNumber} has been credited with  $${amount} by ${userExist.firstName} ${userExist.lastName}`,
                  html: RecieverRequestTemplate(amount, savedRecieverAccount.accountNumber, userExist.firstName, userExist.lastName)
               })

      if (!request || request.error) {
         let error = new Error("an error occurred")
         return next(error)
      }

      //finding beneficiaries with that name
      let beneficiariesFound = await Beneficiaries.findOne({
         accountName: accountName
      })

      //no beneficiaries and needs to add one
      if (!beneficiariesFound && addToFavorite) {
         let newbeneficiaries = new Beneficiaries({
            _id: new mongoose.Types.ObjectId(),
            accountName: accountName,
            accountNumber: accountNumber,
            bankType: 'mybank',
            user: userExist
         })

         let savedBeneficiaries = newbeneficiaries.save()

         if (!savedBeneficiaries) {
            let error = new Error("an error occurred on the server")
            return next(error)
         }
      }
      //fetch and retrieve all account 

      let allAccount = await Account.find({ user: userExist })

      //send transfer object and savedUser to backend
      return res.status(200).json({
         response: {
            transfer: saveTransfer,
            allAccount: allAccount
         }
      })

   } catch (error) {
      error.message = error.message || "an error occured try later"
      return next(error)
   }
}

module.exports.fetchAllAccount = async (req, res, next) => {
   try {

      let token = req.params.token
      let email = await verifyTransactionToken(token)

      let userExist = await User.findOne({ email: email })
      if (!userExist) {
         let error = new Error("user does not exist")
         return next(error)
      }
      let accounts = await Account.find({ user: userExist })

      if (!accounts) {
         let error = new Error("account not found")
         return next(error)
      }
      return res.status(200).json({
         response: accounts
      })
   } catch (error) {
      error.message = error.message || "an error occured try later"
      return next(error)
   }
}

module.exports.fetchAllAccounts = async (req, res, next) => {
   try {
      let token = req.params.token
      let email = await verifyTransactionToken(token)

      let userExist = await User.findOne({ email: email })
      if (!userExist) {
         let error = new Error("user does not exist")
         return next(error)
      }
      let accounts = await Account.find().populate('user')

      console.log(accounts)

      if (!accounts) {
         let error = new Error("account not found")
         return next(error)
      }

      return res.status(200).json({
         response: accounts
      })
   } catch (error) {
      error.message = error.message || "an error occured try later"
      return next(error)
   }
}
//fetch all transfers for this account
module.exports.transfersToAccount = async (req, res, next) => {
   try {
      let token = req.params.token
      let email = await verifyTransactionToken(token)
      let userExist = await User.findOne({ email: email })

      if (!userExist) {
         let error = new Error("user does not exist")
         return next(error)
      }
      //retrieve deposit of this specific user
      let foundHistory = await History.find({ user: userExist })

      if (!foundHistory) {
         let error = new Error("an error occured")
         return next(error)
      }

      return res.status(200).json({
         response: foundHistory
      })

   } catch (error) {
      error.message = error.message || "an error occured try later"
      return next(error)
   }
}
module.exports.history = async (req, res, next) => {
   try {
      let token = req.params.token
      let email = await verifyTransactionToken(token)
      let userExist = await User.findOne({ email: email })

      if (!userExist) {
         let error = new Error("user does not exist")
         return next(error)
      }


      //retrieve deposit of this specific user
      let foundHistory = await History.find({ user: userExist })

      if (!foundHistory) {
         let error = new Error("an error occured")
         return next(error)
      }

      return res.status(200).json({
         response: foundHistory
      })
   } catch (error) {
      error.message = error.message || "an error occured try later"
      return next(error)
   }
}
//send otp code
module.exports.sendOtp = async (req, res, next) => {
   try {
      let token = req.params.token
      let email = await verifyTransactionToken(token)

      let userExist = await User.findOne({ email: email })

      if (!userExist) {
         let error = new Error("user does not exist")
         return next(error)
      }



      let oneTimePassword = userExist.oneTimePassword

      const requests = await resend.emails.send({
                  from: (process.env.RESEND_FROM_EMAIL || "Zentrixx <zentrixx@zentrixx.cloud>"),
                  to: [`${userExist.email}`],
                  subject: "OTP",
                  text: `Your one time password is ${oneTimePassword}`,
                  html: OneTimePasswordTemplate(oneTimePassword)
               })

      if (!requests || requests.error) {
         let error = new Error("an error occurred")
         return next(error)
      }

      return res.status(200).json({
         response: 'an otp code was sent to your phone'
      })


   } catch (error) {
      error.message = error.message || "an error occured try later"
      return next(error)
   }
}
//checking one time password of user
module.exports.checkOtp = async (req, res, next) => {
   try {
      let token = req.params.token
      let email = await verifyTransactionToken(token)

      let userExist = await User.findOne({ email: email })

      if (!userExist) {
         let error = new Error("user does not exist")
         return next(error)
      }

      let { isOtp } = req.body
      //API to send one time password

      if (userExist.oneTimePassword !== isOtp) {
         let error = new Error("incorrect code")
         return next(error)
      }
      userExist.otpVerified = true
      let savedUser = await userExist.save()
      return res.status(200).json({
         response:
         {
            user: savedUser
         }
      })
   } catch (error) {
      error.message = error.message || "an error occured try later"
      return next(error)
   }
}
//fetching all beneficiaries
module.exports.beneficiaries = async (req, res, next) => {
   try {
      let token = req.params.token
      let email = await verifyTransactionToken(token)

      let userExist = await User.findOne({ email: email })

      if (!userExist) {
         let error = new Error("user does not exist")
         return next(error)
      }

      let beneficiaries = await Beneficiaries.find({ user: userExist })

      if (!beneficiaries) {
         let error = new Error("an error occured")
         return next(error)
      }

      return res.status(200).json({
         response: beneficiaries
      })
   } catch (error) {
      error.message = error.message || "an error occured try later"
      return next(error)
   }
}

//creating beneficiaries
module.exports.createBeneficiaries = async (req, res, next) => {
   try {
      let token = req.params.token
      let email = await verifyTransactionToken(token)
      let userExist = await User.findOne({ email: email })
      if (!userExist) {
         let error = new Error("user does not exist")
         return next(error)
      }

      let {
         accountName,
         accountNumber,
         bankName,
         nameOfCountry,
         routeNumber,
         bankType
      } = req.body



      // creating new beneficiaries


      const newBeneficiaries = new Beneficiaries({
         _id: new mongoose.Types.ObjectId(),
         accountName,
         accountNumber,
         bankType,
         bankName,
         nameOfCountry,
         routeNumber,
         user: userExist
      })


      let saveBeneficiaries = await newBeneficiaries.save()

      if (!saveBeneficiaries) {
         let error = new Error("user does not exist")
         return next(error)
      }

      return res.status(200).json({
         response: 'Beneficiary added successfully'
      })
   } catch (error) {
      error.message = error.message || "an error occured try later"
      return next(error)
   }
}
module.exports.deleteBeneficiaries = async (req, res, next) => {
   try {
      let token = req.params.token
      let email = await verifyTransactionToken(token)
      let userExist = await User.findOne({ email: email })
      if (!userExist) {
         let error = new Error("user does not exist")
         return next(error)
      }

      let { id } = req.body

      let deletedBeneficiary = await Beneficiaries.deleteOne({ _id: id })

      if (!deletedBeneficiary) {
         let error = new Error("an error occured")
         return next(error)
      }

      //find every other  benefeciaries by the same user

      let beneficiaries = await Beneficiaries.find({ user: userExist })

      if (!beneficiaries) {
         let error = new Error("an error occured")
         return next(error)
      }

      // creating new beneficiaries

      return res.status(200).json({
         response: beneficiaries
      })
   } catch (error) {
      error.message = error.message || "an error occured try later"
      return next(error)
   }
}
//fetch all notification for this account
module.exports.getNotifications = async (req, res, next) => {
   try {
      let token = req.params.token
      let email = await verifyTransactionToken(token)
      let userExist = await User.findOne({ email: email })
      if (!userExist) {
         let error = new Error("user does not exist")
         return next(error)
      }
      let notifications = await Notification.find({ user: userExist })

      if (!notifications) {
         let error = new Error("an error occured")
         return next(error)
      }
      // creating new beneficiaries

      return res.status(200).json({
         response: notifications
      })
   } catch (error) {
      error.message = error.message || "an error occured try later"
      return next(error)
   }
}

module.exports.deleteNotification = async (req, res, next) => {
   try {
      let token = req.params.token
      console.log(req.body)
      let email = await verifyTransactionToken(token)
      let userExist = await User.findOne({ email: email })
      if (!userExist) {
         let error = new Error("user does not exist")
         return next(error)
      }
      let id = req.params.id


      console.log(req.body)
      let notification = await Notification.deleteOne({ _id: id })
      if (!notification) {
         let error = new Error("an error occured")
         return next(error)
      }

      //find every other  notifications by the same user

      let notifications = await Notification.find({ user: userExist })

      if (!notifications) {
         let error = new Error("an error occured")
         return next(error)
      }

      // creating new notifications
      return res.status(200).json({
         response: notifications
      })
   } catch (error) {
      error.message = error.message || "an error occured try later"
      return next(error)
   }
}

module.exports.loan = async (req, res, next) => {
   try {
      let token = req.params.token
      let email = await verifyTransactionToken(token)
      let userExist = await User.findOne({ email: email })
      if (!userExist) {
         let error = new Error("user does not exist")
         return next(error)
      }

      let {
         marital,
         occupation,
         address,
         amount,
         income,
         purpose,
         duration,
         fullName,
         phone
      } = req.body

      const id = NanoId(10);

      ////Algorithm
      let currentDate = new Date();
      let fourYearDate = `${currentDate.getFullYear()}-${currentDate.getMonth() + 1}-${currentDate.getUTCDate()}`

      let newLoan = new Loan({
         _id: new mongoose.Types.ObjectId(),
         id,
         marital,
         occupation,
         address,
         amount,
         income,
         purpose,
         duration,
         fullName,
         email,
         phone,
         date: fourYearDate,
         user: userExist,
         status: 'pending'
      })


      let savedLoan = await newLoan.save()
      if (!savedLoan) {
         let error = new Error("an error occurred")
         return next(error)
      }

      //creating history
      let newTransfer = new History({
         _id: new mongoose.Types.ObjectId(),
         id: id,
         date: fourYearDate,
         amount,
         reason: 'Application for loan',
         status: 'Pending',
         user: userExist,
         transactionType: 'Loan',
      })


      let savedTransfer = await newTransfer.save()
      if (!savedTransfer) {
         let error = new Error("an error occurred")
         return next(error)
      }

      //sending the user email
      const requests = await resend.emails.send({
                  from: (process.env.RESEND_FROM_EMAIL || "Zentrixx <zentrixx@zentrixx.cloud>"),
                  to: [`${userExist.email}`],
                  subject: "LOAN REQUEST",
                  text: `Your request for a loan of $${amount} has been recieved and awaiting approval!`,
                  html: LoanRequestTemplate(amount)
               })

      if (!requests || requests.error) {
         let error = new Error("an error occurred")
         return next(error)
      }




      let admin = await Admin.find()
      if (!admin[0]) {
         let error = new Error("an error occurred")
         return next(error)

      }

      //send admin email 
      const request = await resend.emails.send({
                  from: (process.env.RESEND_FROM_EMAIL || "Zentrixx <zentrixx@zentrixx.cloud>"),
                  to: [`${admin[0].email}`],
                  subject: "LOAN REQUEST",
                  text: `A user with the email ${userExist.email} request a loan  !`,
                  html: AdminLoanRequestTemplate(userExist.email)
               })

      if (!request || request.error) {

      }

      return res.status(200).json({
         response: 'Loan application successful'
      })





   } catch (error) {
      error.message = error.message || "an error occured try later"
      return next(error)
   }
}




//the admin route
module.exports.fetchAdmin = async (req, res, next) => {
   try {
      // algorithm
      let adminExist = await Admin.find()

      if (!adminExist[0]) {
         let error = new Error("admin not found")
         return next(error)
      }

      return res.status(200).json({
         response: adminExist[0]
      })



   } catch (error) {
      console.log(error)
      error.message = error.message || "an error occured try later"
      return next(error)
   }
}




module.exports.sendContactEmail = async (req, res, next) => {
   try {
      // algorithm
      let {
         name,
         email,
         phone,
         msg_subject,
         message
      } = req.body

      //fetching admin
      let adminExist = await Admin.find()

      if (!adminExist[0]) {
         let error = new Error("admin not found")
         return next(error)
      }

      const requests = await resend.emails.send({
                  from: (process.env.RESEND_FROM_EMAIL || "Zentrixx <zentrixx@zentrixx.cloud>"),
                  to: [`${adminExist[0].email}`],
                  subject: `${msg_subject}`,
                  text: `message from ${name} with email ${email} with the phone ${phone}:
                  XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
                  ${message}`,
                  html: contactEmail(name, email, message, phone)
               })

      if (!requests || requests.error) {

      }

      return res.status(200).json({
         response: 'Email sent. customer care support will get in touch shortly'
      })



   } catch (error) {
      console.log(error)
      error.message = error.message || "an error occured try later"
      return next(error)
   }
}

Admin.find().then(data => {
   console.log(data)
})